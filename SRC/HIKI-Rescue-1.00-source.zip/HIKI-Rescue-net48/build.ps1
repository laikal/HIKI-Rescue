param([switch]$Test)
$ErrorActionPreference = 'Stop'
$vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
if (!(Test-Path -LiteralPath $vswhere)) { throw 'Visual Studio Installer의 vswhere.exe를 찾을 수 없습니다.' }
$msbuild = & $vswhere -latest -products '*' -requires Microsoft.Component.MSBuild -find 'MSBuild\**\Bin\MSBuild.exe' | Select-Object -First 1
if (!$msbuild) { throw 'MSBuild가 필요합니다.' }
& $msbuild (Join-Path $PSScriptRoot 'HIKI Rescue.sln') /m /t:Rebuild /p:Configuration=Release /p:Platform=x64 /nologo /v:minimal
if ($LASTEXITCODE -ne 0) { throw 'Release x64 빌드 실패' }
if ($Test) {
    & (Join-Path $PSScriptRoot 'tests\bin\x64\Release\HikiRescue.Tests.exe') (Join-Path $PSScriptRoot 'docs\검증결과.txt')
    if ($LASTEXITCODE -ne 0) { throw '검증 실패' }
}
