# HIKI Rescue 1.00

Eltax가 Hikimori Neko를 위해 제작한 Windows 복구 및 점검 유틸리티입니다.

## 실행

Windows 10 / 11 x64 및 .NET Framework 4.8이 필요합니다. `bin/x64/Release/HIKI Rescue.exe`를 실행합니다. 배포 ZIP에는 EXE와 EXE.config가 포함됩니다. 추가 NuGet 패키지, 별도 런타임 번들, 외부 이미지·아이콘·DLL은 필요하지 않습니다. Windows 기본 시스템 복원/WMI/복구 도구는 해당 Windows에 설치되어 있어야 합니다.

관리자 권한이 없으면 먼저 설명창을 표시합니다. 사용자가 동의하면 Windows UAC로 한 번 재실행합니다. 취소·실패 시 종료하며, 명령행 인수로 복구 작업을 자동 실행하지 않습니다.

## Visual Studio에서 빌드

1. `HIKI Rescue.sln`을 Visual Studio Community 2026에서 엽니다.
2. **Release / x64**를 선택하고 솔루션을 빌드합니다.
3. `bin/x64/Release/HIKI Rescue.exe`가 생성됩니다.

필요 구성 요소는 .NET 데스크톱 개발 워크로드와 .NET Framework 4.8 SDK/Targeting Pack입니다. 프로젝트를 다른 폴더로 옮겨도 리소스 상대경로를 그대로 사용합니다.

명령행 빌드 및 검증:

```powershell
.\build.ps1 -Test
```

이 스크립트는 개발용입니다. HIKI Rescue 실행 중에는 PowerShell을 호출하지 않습니다. 스크립트는 vswhere로 MSBuild를 찾고 Release x64 빌드 후 독립 테스트 실행기를 실행합니다. 결과는 `docs/검증결과.txt`에 기록됩니다.

## 폴더

- `src/Forms`: 기존 메인 화면, 도움말, About, 관리자 안내창
- `src/Services`: 복원·점검·진단 및 디스플레이 캐시 서비스
- `src/Utilities`: 관리자 확인, 허용된 Windows 도구 실행, 출력 수집
- `src/WindowsApi`: System Restore 및 COM 보안 P/Invoke
- `src/Logging`: 작업별 파일 로그
- `src/Resources`: 원본 멀티사이즈 ICO, About PNG, 한국어 도움말
- `tests`: 호스트 복구 작업을 실행하지 않는 검증 코드
- `docs`: 기존 구현 분석, 기능 대응, 검증 결과와 화면

## 로그와 백업

작업별 UTF-8 로그는 `%LOCALAPPDATA%\HIKI Rescue\Logs\`에 저장되며 화면에 경로가 표시됩니다. 실행 기능·시간·Windows 도구·stdout/stderr·종료 코드·결과를 남깁니다. 별도 Windows GUI 도구는 창 실행 성공만 기록하며 그 도구의 작업 완료로 표시하지 않습니다. 인증정보 입력 기능이 없으며, 로그의 비밀번호·토큰 형태 필드도 가립니다.

디스플레이 캐시 백업은 `%LOCALAPPDATA%\HIKI Rescue\Backups\` 아래 작업별 폴더에 `.reg` 파일로 저장합니다. 파일 저장·검증에 실패한 항목은 삭제하지 않습니다. Windows 레지스트리 편집기의 병합으로 복구할 수 있으나, 현재 설정을 덮어쓰므로 필요한 백업만 선택해야 합니다.

## 검증 범위

Release x64 빌드, 모의 실행 기반 기능·실패 경로 검증, 실제 COM 보안 초기화, 내장 리소스·아이콘 검증 및 화면 렌더링을 완료했습니다. 실제 UAC 승인/취소와 시스템 변경 작업(복원 지점 생성, DISM/SFC, CHKDSK 예약, HKLM 캐시 삭제, DNS 초기화, 재부팅)은 이 환경에서 실행하지 않았습니다. 상세 구분은 `docs/분석-및-검증.md`에 있습니다.

Copyright © Eltax
