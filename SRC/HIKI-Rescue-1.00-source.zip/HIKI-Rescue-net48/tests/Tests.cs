using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace HikiRescue
{
    internal static class Tests
    {
        private sealed class FakeRunner : ICommandRunner
        {
            public readonly List<string> Calls = new List<string>();
            public Func<string, string, CommandResult> Answer;
            public Task<CommandResult> Run(string exe, string args, string input, bool unicode, Action<string> output)
            {
                Calls.Add(exe + " " + args);
                return Task.FromResult(Answer == null ? new CommandResult(0, "") : Answer(exe, args));
            }
        }
        private static void Check(bool condition, string message)
        {
            if (!condition) throw new Exception(message);
        }
        public static async Task<string> Run()
        {
            var report = new StringBuilder();
            report.Append(StartupTests.Run());
            report.Append(await DiagnosticTests.Run());
            var topics = HelpForm.LoadTopics();
            Check(topics.Count == 14 && topics.All(x => x.Body.Length > 100), "Embedded help missing");
            report.AppendLine("PASS: all fourteen embedded help topics are readable without external files");
            Check(Recovery.ParseProgress("[==== 56.8% ===]") == 56 && Recovery.ParseProgress("검증 23% 완료") == 23 &&
                Recovery.ParseProgress("56,8%") == 56 && Recovery.ParseProgress("1234%") == null && Recovery.ParseProgress("오류 0x800f") == null,
                "Progress parsing");
            report.AppendLine("PASS: localized progress and malformed output handling");
            var fake = new FakeRunner { Answer = (e, a) => new CommandResult(5, "access denied") };
            bool failed = false;
            try { await new Recovery(fake).Repair(s => { }, s => { }); } catch (InvalidOperationException) { failed = true; }
            Check(failed && fake.Calls.Count == 1 && fake.Calls[0].StartsWith("dism.exe"), "SFC ran after DISM failure");
            report.AppendLine("PASS: DISM failure prevents SFC");
            fake = new FakeRunner { Answer = (e, a) => new CommandResult(3010, "") };
            string result = await new Recovery(fake).Repair(s => { }, s => { });
            Check(fake.Calls.Count == 1 && result.Contains("재부팅"), "Pending reboot not honored");
            report.AppendLine("PASS: DISM pending reboot prevents SFC");
            fake = new FakeRunner();
            await new Recovery(fake).Repair(s => { }, s => { });
            Check(fake.Calls.Count == 2 && fake.Calls[1] == "sfc.exe /scannow", "Successful sequence");
            report.AppendLine("PASS: SFC runs after successful DISM");
            fake = new FakeRunner { Answer = (e, a) => new CommandResult(e == "sfc.exe" ? 1 : 0, "") };
            failed = false;
            try { await new Recovery(fake).Repair(s => { }, s => { }); } catch (InvalidOperationException) { failed = true; }
            Check(failed, "SFC failure suppressed");
            report.AppendLine("PASS: SFC failures are surfaced");
            report.Append(RestoreTests.Run());
            Check(!Recovery.HasScheduledScan(new[] { "autocheck autochk *" }, "C:") &&
                !Recovery.HasScheduledScan(new[] { @"autocheck autochk /r \??\D:" }, "C:") &&
                Recovery.HasScheduledScan(new[] { @"autocheck autochk /r \??\C:" }, "C:"), "Boot verification");
            report.AppendLine("PASS: only explicit /R scheduling for the correct volume is accepted");
            report.Append(await RefactorTests.Run());
            report.AppendLine("No recovery tools, registry mutations, elevation or reboot were executed by these tests.");
            return report.ToString();
        }
    }
}
