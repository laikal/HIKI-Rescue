using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Versioning;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace HikiRescue
{
    internal static class RefactorTests
    {
        private static void Check(bool value, string message) { if (!value) throw new Exception(message); }
        private sealed class Registry : IDisplayRegistry
        {
            internal readonly List<string> Deleted = new List<string>();
            internal readonly Dictionary<string, int> Reads = new Dictionary<string, int>();
            internal string FailingRead, FailingDelete, Changing, Unsupported;
            public RegistryNode Read(string name)
            {
                int count; Reads.TryGetValue(name, out count); Reads[name] = ++count;
                if (name == FailingRead) throw new UnauthorizedAccessException("테스트용 접근 거부");
                var node = new RegistryNode { Name = name };
                node.Values.Add(new RegistryValueData { Name = "value", Kind = name == Unsupported ? RegistryValueKind.Unknown : RegistryValueKind.DWord,
                    Value = name == Changing ? count : 10 });
                return node;
            }
            public void Delete(string name)
            {
                if (name == FailingDelete) throw new UnauthorizedAccessException("테스트용 삭제 거부");
                Deleted.Add(name);
            }
        }
        private static string Folder(string root, string suffix) { string path = Path.Combine(root, suffix); Directory.CreateDirectory(path); return path; }
        internal static async Task<string> Run()
        {
            var report = new StringBuilder();
            string root = Path.Combine(Path.GetTempPath(), "HikiRefactorTests-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(root);
            try {
                var node = new RegistryNode { Name = "Configuration" };
                node.Values.Add(new RegistryValueData { Name = "", Kind = RegistryValueKind.String, Value = "한글\r\n줄" });
                node.Values.Add(new RegistryValueData { Name = "a\"b\\c", Kind = RegistryValueKind.DWord, Value = -1 });
                node.Values.Add(new RegistryValueData { Name = "expand", Kind = RegistryValueKind.ExpandString, Value = "%TEMP%" });
                node.Values.Add(new RegistryValueData { Name = "qword", Kind = RegistryValueKind.QWord, Value = 0x0102030405060708L });
                node.Values.Add(new RegistryValueData { Name = "multi", Kind = RegistryValueKind.MultiString, Value = new[] { "가", "나" } });
                node.Values.Add(new RegistryValueData { Name = "binary", Kind = RegistryValueKind.Binary, Value = new byte[] { 0, 0x80, 255 } });
                node.Values.Add(new RegistryValueData { Name = "none", Kind = RegistryValueKind.None, Value = new byte[0] });
                node.Children.Add(new RegistryNode { Name = "nested" });
                string text = RegistryBackup.Export("Configuration", node);
                Check(text.Contains("@=hex(1):") && text.Contains("\"a\\\"b\\\\c\"=dword:ffffffff") &&
                    text.Contains("hex(b):08,07,06,05,04,03,02,01") && text.Contains("hex:00,80,ff") &&
                    text.Contains("hex(7):00,ac,00,00,98,b0,00,00,00,00") && text.Contains("Configuration\\nested]"), "Registry export formats");
                string file = Path.Combine(root, "fixture.reg"); RegistryBackup.SaveAndVerify(file, text);
                byte[] bytes = File.ReadAllBytes(file);
                Check(bytes[0] == 255 && bytes[1] == 254 && File.ReadAllText(file) == text, "UTF-16 durable backup verification");
                report.AppendLine("PASS: .reg export handles default/nested values, Korean/newline strings, expandable/multi strings, unsigned DWORD, little-endian QWORD, binary and NONE");
                foreach (string fault in new[] { "read", "write", "changed", "unsupported", "delete" }) {
                    var registry = new Registry { FailingRead = fault == "read" ? "Connectivity" : null,
                        FailingDelete = fault == "delete" ? "Connectivity" : null,
                        Changing = fault == "changed" ? "Connectivity" : null, Unsupported = fault == "unsupported" ? "Connectivity" : null };
                    string directory = Folder(root, fault);
                    if (fault == "write") Directory.CreateDirectory(Path.Combine(directory, "Connectivity.reg"));
                    string result = new DisplayCacheService(registry).Reset(directory, s => { });
                    Check(registry.Deleted.SequenceEqual(new[] { "Configuration", "ScaleFactors" }) && result.Contains("2 / 3"), "Unsafe deletion on " + fault);
                    foreach (string deleted in registry.Deleted) Check(File.Exists(Path.Combine(directory, deleted + ".reg")), "Delete without backup");
                }
                report.AppendLine("PASS: registry read/export/write/change/delete failures are isolated per key; unverified backups never authorize deletion");
                bool rejected = false;
                try { new DisplayRegistry().Delete("NVIDIA"); } catch (ArgumentException) { rejected = true; }
                Check(rejected, "Registry target allow-list");
                report.AppendLine("PASS: unrelated driver registry targets rejected before any Windows registry call");
                foreach (var encoding in new[] { Encoding.UTF8, Encoding.Unicode }) {
                    var lines = new List<string>();
                    using (var reader = new StreamReader(new MemoryStream(encoding.GetBytes("진행 12%\r진행 100%\r\n끝")), encoding))
                        await CommandRunner.Pump(reader, lines.Add);
                    Check(lines.SequenceEqual(new[] { "진행 12%", "진행 100%", "끝" }), "Redirected progress parsing");
                }
                report.AppendLine("PASS: redirected stream parser handles carriage-return progress, Korean text and UTF-16 without launching a shell");
                foreach (string exe in new[] { "unknown.exe", "..\\dism.exe", "C:\\dism.exe" }) {
                    rejected = false; try { WindowsTools.Validate(exe, ""); } catch (ArgumentException) { rejected = true; } Check(rejected, "Unknown tool accepted");
                }
                rejected = false; try { WindowsTools.Validate("ipconfig.exe", "/release"); } catch (ArgumentException) { rejected = true; } Check(rejected, "Non-DNS network mutation accepted");
                Check(Path.IsPathRooted(WindowsTools.Validate("ipconfig.exe", "/flushdns")), "Relative executable path");
                report.AppendLine("PASS: executable and argument allow-list rejects alternative commands and arbitrary paths");
                string logPath;
                using (var log = OperationLog.Begin("テスト / 진단", Folder(root, "logs"))) {
                    logPath = log.FilePath;
                    OperationLog.Write("stdout", "진행 100%"); OperationLog.Write("stderr", "예제 오류");
                    OperationLog.Write("종료 코드", "0"); OperationLog.Write("보안", "token=example-secret");
                    OperationLog.Result(true, "완료");
                }
                string contents = File.ReadAllText(logPath);
                Check(contents.Contains("stdout") && contents.Contains("stderr") && contents.Contains("종료 코드") && contents.Contains("성공") && !contents.Contains("example-secret"), "Log content/redaction");
                report.AppendLine("PASS: persistent UTF-8 logs contain time, function, streams, exit/result and redact credential-like fields");
                var app = System.Reflection.Assembly.LoadFrom(Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "..", "..", "..", "..", "bin", "x64", "Release", "HIKI Rescue.exe")));
                var target = (TargetFrameworkAttribute)Attribute.GetCustomAttribute(app, typeof(TargetFrameworkAttribute));
                Check(target != null && target.FrameworkName == ".NETFramework,Version=v4.8" && Environment.Is64BitProcess, "Framework/platform");
                Check(app.GetType("HikiRescue.Tests") == null && app.GetType("HikiRescue.TestProgram") == null, "Test code shipped in app");
                report.AppendLine("PASS: real .NET Framework 4.8 x64 target; tests and preview code absent from application assembly");
            }
            finally {
                string full = Path.GetFullPath(root);
                if (full.StartsWith(Path.GetFullPath(Path.GetTempPath()), StringComparison.OrdinalIgnoreCase) && Path.GetFileName(full).StartsWith("HikiRefactorTests-"))
                    Directory.Delete(full, true);
            }
            return report.ToString();
        }
    }
}

