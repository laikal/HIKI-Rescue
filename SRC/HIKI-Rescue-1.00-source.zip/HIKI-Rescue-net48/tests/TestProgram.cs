using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace HikiRescue
{
    internal static class TestProgram
    {
        [STAThread]
        static int Main(string[] args)
        {
            bool administrator = Recovery.IsAdmin;
            NativeRestore.InitializeSecurity();
            return Run(args);
        }
        [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
        static int Run(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            if (args.Length == 2 && args[0] == "--preview") {
                Directory.CreateDirectory(args[1]);
                Render(new MainForm(), Path.Combine(args[1], "main.png"));
                Render(new HelpForm(0), Path.Combine(args[1], "help.png"));
                Render(new AboutForm(), Path.Combine(args[1], "about.png"));
                Render(new AdminPromptForm(), Path.Combine(args[1], "admin.png"));
                return 0;
            }
            try {
                string report = Tests.Run().GetAwaiter().GetResult();
                if (args.Length == 1) File.WriteAllText(args[0], report, Encoding.UTF8);
                Console.WriteLine(report); return 0;
            }
            catch (Exception ex) {
                if (args.Length == 1) File.WriteAllText(args[0], "FAIL\r\n" + ex, Encoding.UTF8);
                Console.Error.WriteLine(ex); return 1;
            }
        }
        private static void Render(Form form, string path)
        {
            using (form) {
                // Diagnostic rendering is inert, including when invoked by a non-admin build/test process.
                if (form is MainForm) form.Enabled = false;
                form.Show(); Application.DoEvents();
                using (var bitmap = new Bitmap(form.Width, form.Height)) {
                    form.DrawToBitmap(bitmap, new Rectangle(Point.Empty, form.Size));
                    using (var graphics = Graphics.FromImage(bitmap)) RenderRichText(form, form, graphics);
                    bitmap.Save(path, System.Drawing.Imaging.ImageFormat.Png);
                }
                form.Close();
            }
        }
        [StructLayout(LayoutKind.Sequential)] private struct Rect { public int Left, Top, Right, Bottom; }
        [StructLayout(LayoutKind.Sequential)] private struct Range { public int Min, Max; }
        [StructLayout(LayoutKind.Sequential)] private struct FormatRange { public IntPtr Hdc, Target; public Rect Area, Page; public Range Range; }
        [DllImport("user32.dll", CharSet = CharSet.Auto)] private static extern IntPtr SendMessage(IntPtr hwnd, int msg, IntPtr w, IntPtr l);
        private static void RenderRichText(Control parent, Form form, Graphics graphics)
        {
            foreach (Control control in parent.Controls) {
                var rich = control as RichTextBox;
                if (rich != null) {
                    Point point = rich.PointToScreen(Point.Empty); point.Offset(-form.Left, -form.Top);
                    Rectangle bounds = new Rectangle(point, rich.ClientSize);
                    using (var brush = new SolidBrush(rich.BackColor)) graphics.FillRectangle(brush, bounds);
                    float factor = 1440F / graphics.DpiX;
                    Rect area = new Rect { Left = (int)(bounds.Left * factor), Top = (int)(bounds.Top * factor), Right = (int)(bounds.Right * factor), Bottom = (int)(bounds.Bottom * factor) };
                    IntPtr hdc = graphics.GetHdc();
                    IntPtr ptr = Marshal.AllocCoTaskMem(Marshal.SizeOf(typeof(FormatRange)));
                    try {
                        var format = new FormatRange { Hdc = hdc, Target = hdc, Area = area, Page = area, Range = new Range { Min = 0, Max = -1 } };
                        Marshal.StructureToPtr(format, ptr, false); SendMessage(rich.Handle, 0x0439, new IntPtr(1), ptr);
                    }
                    finally { SendMessage(rich.Handle, 0x0439, IntPtr.Zero, IntPtr.Zero); Marshal.FreeCoTaskMem(ptr); graphics.ReleaseHdc(hdc); }
                }
                else RenderRichText(control, form, graphics);
            }
        }
    }
}

