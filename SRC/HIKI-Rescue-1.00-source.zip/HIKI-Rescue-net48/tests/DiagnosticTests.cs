using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HikiRescue
{
    internal static class DiagnosticTests
    {
        private sealed class Runner : ICommandRunner
        {
            public int Calls, Code;
            public bool Throw;
            public Task<CommandResult> Run(string exe, string args, string input, bool unicode, Action<string> output)
            {
                Calls++;
                Check(exe == "ipconfig.exe" && args == "/flushdns" && input == null && output == null, "Unexpected DNS operation/output");
                if (Throw) throw new System.ComponentModel.Win32Exception(5);
                return Task.FromResult(new CommandResult(Code, "Unlocalized Windows output"));
            }
        }
        private static void Check(bool value, string message) { if (!value) throw new Exception(message); }
        public static async Task<string> Run()
        {
            var report = new StringBuilder();
            var runner = new Runner();
            var calls = new List<string>();
            var tools = new DiagnosticTools(runner, (exe, args) => calls.Add(exe + "|" + args));
            foreach (string action in new[] { "reliability", "memory", "pcinfo", "cleanup" }) tools.Open(action);
            Check(calls.SequenceEqual(new[] { "perfmon.exe|/rel", "mdsched.exe|", "msinfo32.exe|", "cleanmgr.exe|" }) && runner.Calls == 0, "Viewer mapping or unexpected command");
            report.AppendLine("PASS: built-in viewers use exact commands; memory and cleanup receive no automation/reboot arguments");
            var failureTools = new DiagnosticTools(runner, (exe, args) => { throw new System.ComponentModel.Win32Exception(2); });
            string[] ids = { "reliability", "memory", "pcinfo", "cleanup" };
            string[] errors = { "Windows 문제 기록을 열 수 없습니다.", "Windows 메모리 진단을 실행할 수 없습니다.", "Windows 시스템 정보를 열 수 없습니다.", "Windows 디스크 정리를 실행할 수 없습니다." };
            for (int i = 0; i < ids.Length; i++) {
                bool failed = false;
                try { failureTools.Open(ids[i]); } catch (DiagnosticFailure ex) { failed = true; Check(ex.Message == errors[i] && ex.Code == 2, "Viewer error"); }
                Check(failed, "Viewer failure swallowed");
            }
            report.AppendLine("PASS: viewer launch failures have the requested Korean messages and error codes");
            Check(await tools.FlushDns() == "DNS 캐시를 초기화했습니다." && runner.Calls == 1, "DNS success");
            foreach (bool throws in new[] { false, true }) {
                runner.Code = 1; runner.Throw = throws; bool failed = false;
                try { await tools.FlushDns(); } catch (DiagnosticFailure ex) {
                    failed = true; Check(ex.Message == "DNS 캐시 초기화에 실패했습니다." && ex.Code == (throws ? 5 : 1), "DNS error");
                }
                Check(failed, "DNS failure swallowed");
            }
            Check(runner.Calls == 3, "Unexpected additional network command");
            report.AppendLine("PASS: DNS invokes only ipconfig /flushdns once; exit/start failures are localized; raw output is not shown");
            var topics = HelpForm.LoadTopics();
            foreach (string title in new[] { "복원 지점 만들기", "시스템 복원", "Windows 점검 및 복구", "디스크 정밀 검사", "메모리 진단", "디스플레이 캐시 초기화", "DNS 캐시 초기화", "Windows 디스크 정리", "문제 기록 보기", "PC 정보 보기" })
                Check(topics.Count(t => t.Title == title && t.Body.Length > 100) == 1, "Missing/duplicate contextual help: " + title);
            report.AppendLine("PASS: all ten function buttons have matching embedded help topics");
            report.AppendLine("LIVE diagnostic launch/DNS flush: NOT RUN; tests use injected processes without changing the host.");
            return report.ToString();
        }
    }
}
