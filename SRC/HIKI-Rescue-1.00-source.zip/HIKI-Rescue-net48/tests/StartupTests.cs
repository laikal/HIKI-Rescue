using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;

namespace HikiRescue
{
    internal static class StartupTests
    {
        private static void Check(bool condition, string name) { if (!condition) throw new Exception(name); }
        internal static string Run()
        {
            var report = new StringBuilder();
            int prompts = 0, launches = 0, failures = 0;
            Action<string> failure = s => { Check(s == Startup.FailedMessage, "Failure message"); failures++; };
            foreach (bool attempted in new[] { false, true })
                Check(Startup.Check(true, attempted, () => { prompts++; return true; }, () => launches++, failure), "Administrator denied");
            Check(prompts == 0 && launches == 0 && failures == 0, "Administrator re-prompted");
            report.AppendLine("PASS: actual administrator enters directly, including after relaunch; no repeated prompt");
            Check(!Startup.Check(false, false, () => { prompts++; return false; }, () => launches++, failure), "Exit entered main");
            Check(prompts == 1 && launches == 0 && failures == 0, "Exit launched UAC");
            report.AppendLine("PASS: choosing Exit never launches UAC or enters main");
            Check(!Startup.Check(false, false, () => true, () => launches++, failure) && launches == 1, "Parent continued after launch");
            report.AppendLine("PASS: successful relaunch terminates the original startup flow");
            foreach (Exception ex in new Exception[] { new Win32Exception(1223), new Win32Exception(5), new InvalidOperationException() }) {
                Check(!Startup.Check(false, false, () => true, () => { throw ex; }, failure), "Failed launch entered main");
            }
            Check(failures == 3, "UAC cancellation/failure not reported");
            report.AppendLine("PASS: simulated UAC cancellation and launch failures display the requested message and exit");
            prompts = 0; launches = 0;
            Check(!Startup.Check(false, true, () => { prompts++; return true; }, () => launches++, failure), "Marker granted access");
            Check(prompts == 0 && launches == 0 && failures == 4, "Relaunch loop");
            report.AppendLine("PASS: failed elevation marker never grants access and cannot loop");
            var start = Startup.ElevationInfo(@"C:\Program Files\HIKI Rescue\HIKI Rescue.exe");
            Check(start.UseShellExecute && start.Verb == "runas" && start.FileName.EndsWith("HIKI Rescue.exe") &&
                start.Arguments == "--elevated", "Elevation settings");
            report.AppendLine("PASS: runas uses the executable path and does not forward automatic repair arguments");
            using (var image = (Bitmap)AboutForm.LoadCharacter()) {
                Check(image.Width == 640 && image.Height == 640 && image.GetPixel(0, 0).A == 0, "Embedded PNG dimensions/transparency");
            }
            var assembly = typeof(Metadata).Assembly;
            var version = FileVersionInfo.GetVersionInfo(assembly.Location);
            Check(version.CompanyName == "Eltax" && version.ProductName == "HIKI Rescue" && version.ProductVersion == "1.00" &&
                version.FileVersion == "1.0.0.0" && version.LegalCopyright == "Copyright © Eltax", "EXE version metadata");
            var attributes = assembly.GetCustomAttributes(typeof(AssemblyMetadataAttribute), false).Cast<AssemblyMetadataAttribute>();
            Check(attributes.Any(x => x.Key == "Author" && x.Value == "Eltax") && attributes.Any(x => x.Key == "Developer" && x.Value == "Eltax"), "Developer metadata");
            report.AppendLine("PASS: original transparent 640x640 PNG loads from the EXE; Eltax/version metadata matches");
            report.AppendLine("LIVE UAC acceptance/cancellation: NOT RUN; startup branches tested with injected launch results.");
            return report.ToString();
        }
    }
}
