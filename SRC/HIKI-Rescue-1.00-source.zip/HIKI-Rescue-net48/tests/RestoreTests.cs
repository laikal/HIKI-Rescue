using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

namespace HikiRescue
{
    internal static class RestoreTests
    {
        private sealed class FakePlatform : IRestorePlatform
        {
            public bool Admin = true;
            public ProtectionState Protection = ProtectionState.Enabled;
            public FrequencyState Frequency = new FrequencyState();
            public List<RestorePointRecord> Points = new List<RestorePointRecord>();
            public DateTime Clock = new DateTime(2026, 9, 18, 10, 5, 22);
            public bool Skip, WrongName, ApiError, QueryError, RollbackError, WriteError, DirtyWriteError;
            public int Creates, Writes, Lists;
            public bool IsAdmin { get { return Admin; } }
            public DateTime Now { get { return Clock; } }
            public ProtectionState CheckProtection() { return Protection; }
            public IList<RestorePointRecord> ListPoints() {
                Lists++;
                if (QueryError && Creates > 0) throw new COMException("WMI query failed", unchecked((int)0x80041001));
                return Points.ToArray();
            }
            public FrequencyState ReadFrequency() { return new FrequencyState { Exists = Frequency.Exists, Value = Frequency.Value }; }
            public void WriteFrequency(FrequencyState state) {
                Writes++;
                if (WriteError && Writes == 1) throw new UnauthorizedAccessException("denied");
                if (RollbackError && Writes > 1) throw new UnauthorizedAccessException("denied rollback");
                Frequency = new FrequencyState { Exists = state.Exists, Value = state.Value };
                if (DirtyWriteError && Writes == 1) throw new InvalidOperationException("write completed but flush failed");
            }
            public long CreateNative(string description, Action<string> output) {
                Check(Frequency.Exists && Frequency.Value == 0, "Native API invoked without the temporary DWORD=0");
                Creates++;
                if (ApiError) throw RestoreFailure.Api(112, "native begin");
                long highest = Points.Count == 0 ? 0 : Points.Max(x => x.Sequence);
                if (Skip) return highest;
                Points.Add(new RestorePointRecord { Sequence = highest + 1, Description = WrongName ? "Other software" : description, Created = Clock });
                return highest + 1;
            }
            public void WaitForList() { }
        }
        private static void Check(bool condition, string message) { if (!condition) throw new Exception(message); }
        private static RestoreFailure Fails(FakePlatform platform, List<string> log)
        {
            try { new RestorePointService(platform).Create(log.Add); }
            catch (RestoreFailure failure) { return failure; }
            throw new Exception("Expected a failure, but creation was reported as successful");
        }
        public static string Run()
        {
            var report = new StringBuilder();
            NativeRestore.RequireSecurity();
            report.AppendLine("PASS: real process COM callback security initialization (no restore API call)");
            Check(Marshal.SizeOf(typeof(NativeRestore.RestoreInfo)) == 528 && Marshal.SizeOf(typeof(NativeRestore.RestoreStatus)) == 12 &&
                Marshal.OffsetOf(typeof(NativeRestore.RestoreStatus), "Sequence").ToInt32() == 4, "System Restore ABI packing mismatch");
            report.AppendLine("PASS: native Unicode structure sizes and packed 64-bit sequence offset");
            var log = new List<string>();
            var p = new FakePlatform();
            var first = new RestorePointService(p).Create(log.Add);
            Check(first.Sequence == 1 && first.Description == "HIKI Restore - 2026-09-18 10-05-22" && !p.Frequency.Exists, "A/C/E");
            Check(first.SuccessMessage.StartsWith("복원 지점이 생성되었습니다.") && first.StatusMessage.Contains("2026-09-18 10:05:22"), "Success UI contract");
            report.AppendLine("PASS [SIMULATED A/C/E]: no previous point -> verified new sequence and description; originally absent value removed");
            p.Clock = p.Clock.AddMinutes(2);
            p.Frequency = new FrequencyState { Exists = true, Value = 1440 };
            var second = new RestorePointService(p).Create(log.Add);
            Check(second.Sequence > first.Sequence && p.Points.Count == 2 && p.Frequency.Exists && p.Frequency.Value == 1440, "B/C/E");
            report.AppendLine("PASS [SIMULATED B/C/E]: point two minutes later is created with DWORD=0; original 1440 restored");
            foreach (int original in new[] { 0, 60, -1, int.MinValue }) {
                p = new FakePlatform { Frequency = new FrequencyState { Exists = true, Value = original } };
                new RestorePointService(p).Create(log.Add);
                Check(p.Frequency.Exists && p.Frequency.Value == original, "Original DWORD bits lost");
            }
            report.AppendLine("PASS [SIMULATED C]: original zero and full unsigned DWORD bit patterns are preserved");
            foreach (bool exists in new[] { false, true }) {
                foreach (string fault in new[] { "api", "query", "write", "dirty-write", "skip", "name" }) {
                    p = new FakePlatform { Frequency = new FrequencyState { Exists = exists, Value = 1440 }, ApiError = fault == "api",
                        QueryError = fault == "query", WriteError = fault == "write", DirtyWriteError = fault == "dirty-write", Skip = fault == "skip", WrongName = fault == "name" };
                    Fails(p, log);
                    Check(p.Frequency.Exists == exists && (!exists || p.Frequency.Value == 1440), "Rollback failed: " + fault);
                    if (fault == "write" || fault == "dirty-write") Check(p.Creates == 0, "API ran after setting failure");
                }
            }
            report.AppendLine("PASS [SIMULATED C]: rollback after API, WMI, initial write/flush, skipped creation and wrong-description failures (present and absent)");
            p = new FakePlatform { Skip = true };
            p.Points.Add(new RestorePointRecord { Sequence = 55, Description = "HIKI Restore - 2026-09-18 10-05-22", Created = p.Clock });
            var failure = Fails(p, log);
            Check(failure.Stage == "생성 후 목록 검증", "Existing same-name point accepted");
            report.AppendLine("PASS: API success returning an old same-name point never produces success");
            p = new FakePlatform { RollbackError = true };
            failure = Fails(p, log);
            Check(failure.Stage == "생성 제한 원상복구" && p.Writes == 4 && failure.Message.Contains("새 복원 지점은 확인"), "Rollback error suppressed");
            report.AppendLine("PASS: rollback failure is retried and reported distinctly even when a point exists");
            foreach (ProtectionState state in new[] { ProtectionState.Disabled, ProtectionState.Unknown }) {
                p = new FakePlatform { Protection = state };
                failure = Fails(p, log);
                Check(p.Creates == 0 && p.Writes == 0 && p.Lists == 0 && failure.ProtectionDisabled == (state == ProtectionState.Disabled), "Protection preflight");
            }
            p = new FakePlatform { Admin = false }; failure = Fails(p, log);
            Check(failure.Code == 5 && p.Writes == 0 && p.Creates == 0, "Admin gate");
            report.AppendLine("PASS: disabled/unknown protection and non-admin states prevent registry changes and API calls");
            string volume = @"\\?\Volume{12345678-1234-1234-1234-123456789012}\";
            Check(WindowsRestorePlatform.IsRegisteredVolume(new[] { volume }, volume) &&
                WindowsRestorePlatform.IsRegisteredVolume(new[] { volume + ":Windows:C%3A\\:scope" }, volume) &&
                !WindowsRestorePlatform.IsRegisteredVolume(new[] { @"\\?\Volume{00000000-0000-0000-0000-000000000000}\:C%3A" }, volume), "SPP volume parser");
            report.AppendLine("PASS: system volume matching accepts SPP metadata and rejects other volumes");
            Check(RestoreFailure.Api(112, "native").Message.Contains("저장 공간") && RestoreFailure.Api(0x8004231F, "native").Message.Contains("저장 공간") &&
                RestoreFailure.Api(0x80042306, "native").Message.Contains("VSS") && RestoreFailure.Api(1058, "native").ProtectionDisabled,
                "Error classifications");
            report.AppendLine("PASS: disabled protection, disk-space and VSS codes have distinct messages");
            foreach (string bad in new[] { "#< CLIXML", "System.Management.Automation.WarningRecord", "PSCUSTOMOBJECT", "ProgressRecord", "<?xml version='1.0'?>", "<Objs Version='1'>" })
                Check(!RestorePointService.SafeLog(bad).Contains(bad), "Unsafe GUI output");
            Check(log.All(x => x.StartsWith("[") && !x.Contains("CLIXML") && !x.Contains("System.Management.Automation")), "Unsafe generated logs");
            Check(log.IndexOf(log.First(x => x.Contains("새 복원 지점 확인 완료"))) < log.IndexOf(log.First(x => x.Contains("생성 제한 설정을 원래 상태로"))), "Verification/cleanup order");
            report.AppendLine("PASS [D]: human-readable timestamped logs; serialized/internal output is filtered");
            report.AppendLine("LIVE A/B/C/E: NOT RUN. These cases used a fake registry and fake restore API; no host restore points were created.");
            return report.ToString();
        }
    }
}
