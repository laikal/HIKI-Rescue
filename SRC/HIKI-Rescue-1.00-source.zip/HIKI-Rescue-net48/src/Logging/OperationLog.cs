using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace HikiRescue
{
    internal sealed class OperationLog : IDisposable
    {
        private static readonly object Gate = new object();
        private static OperationLog active;
        private readonly StreamWriter writer;
        internal string FilePath { get; private set; }
        internal bool WriteFailed { get; private set; }
        private string outcome = "사용자 취소 또는 종료";
        private OperationLog(string directory, string feature)
        {
            Directory.CreateDirectory(directory);
            FilePath = Path.Combine(directory, DateTime.Now.ToString("yyyyMMdd-HHmmss-fff") + "-" + Guid.NewGuid().ToString("N").Substring(0, 8) + ".log");
            writer = new StreamWriter(new FileStream(FilePath, FileMode.CreateNew, FileAccess.Write, FileShare.Read), new UTF8Encoding(false)) { AutoFlush = true };
            WriteLine("시작", feature);
        }
        internal static OperationLog Begin(string feature, string directory = null)
        {
            lock (Gate) {
                if (active != null) throw new InvalidOperationException("다른 작업의 로그가 열려 있습니다.");
                active = new OperationLog(directory ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "HIKI Rescue", "Logs"), feature);
                return active;
            }
        }
        internal static string Redact(string text)
        {
            // Only allow-listed tool arguments are supplied; additionally redact credential-like fields in tool output.
            return Regex.Replace(text ?? "", @"(?i)\b(password|passwd|token|secret|authorization)\b\s*[:=]\s*[^\r\n]+", "$1=[비공개]");
        }
        internal static void Write(string category, string text)
        {
            lock (Gate) { if (active != null) active.WriteLine(category, text); }
        }
        internal static void Result(bool success, string text)
        {
            lock (Gate) {
                if (active == null) return;
                active.outcome = success ? "성공 / 실행 완료" : "실패 또는 일부 실패";
                active.WriteLine(active.outcome, text);
            }
        }
        private void WriteLine(string category, string text)
        {
            try { writer.WriteLine("[{0:yyyy-MM-dd HH:mm:ss.fff}] [{1}] {2}", DateTime.Now, category, Redact(text)); }
            catch (IOException) { WriteFailed = true; }
            catch (UnauthorizedAccessException) { WriteFailed = true; }
        }
        public void Dispose()
        {
            lock (Gate) {
                if (active != this) return;
                WriteLine("종료", outcome);
                try { writer.Dispose(); } catch (IOException) { WriteFailed = true; }
                active = null;
            }
        }
    }
}
