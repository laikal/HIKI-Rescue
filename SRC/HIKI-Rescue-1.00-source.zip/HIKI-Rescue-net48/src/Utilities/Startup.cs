using System;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace HikiRescue
{
    internal static class Startup
    {
        internal const string FailedMessage = "관리자 권한을 얻지 못했습니다.\r\nHIKI Rescue를 종료합니다.";
        internal static bool Check(bool isAdministrator, bool alreadyAttempted, Func<bool> ask, Action relaunch, Action<string> showFailure)
        {
            // Only the actual Windows token grants access. The marker merely prevents repeated UAC attempts.
            if (isAdministrator) return true;
            if (alreadyAttempted) { showFailure(FailedMessage); return false; }
            if (!ask()) return false;
            try { relaunch(); }
            catch (Exception) { showFailure(FailedMessage); }
            // Successful launch, cancellation and failure all terminate the original process.
            return false;
        }
        internal static ProcessStartInfo ElevationInfo(string executable)
        {
            return new ProcessStartInfo(executable, "--elevated") { UseShellExecute = true, Verb = "runas" };
        }
        internal static bool EnterMain(bool isAdministrator, string[] args)
        {
            return Check(isAdministrator, args.Contains("--elevated"), delegate {
                using (var dialog = new AdminPromptForm()) return dialog.ShowDialog() == DialogResult.OK;
            }, delegate {
                using (var process = Process.Start(ElevationInfo(Application.ExecutablePath))) {
                    if (process == null) throw new InvalidOperationException("No elevated process was started.");
                }
            }, message => MessageBox.Show(message, Metadata.Name, MessageBoxButtons.OK, MessageBoxIcon.Warning));
        }
    }
}
