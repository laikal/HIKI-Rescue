using System;
using System.Diagnostics;
using System.IO;

namespace HikiRescue
{
    internal static class WindowsTools
    {
        internal static string Validate(string exe, string args)
        {
            bool valid;
            switch (exe) {
                case "dism.exe": valid = args == "/Online /Cleanup-Image /RestoreHealth"; break;
                case "sfc.exe": valid = args == "/scannow"; break;
                case "ipconfig.exe": valid = args == "/flushdns"; break;
                case "chkdsk.exe": valid = args == Path.GetPathRoot(Environment.SystemDirectory).TrimEnd('\\') + " /R"; break;
                case "perfmon.exe": valid = args == "/rel"; break;
                case "shutdown.exe": valid = args == "/r /t 0"; break;
                case "rstrui.exe": case "mdsched.exe": case "msinfo32.exe": case "cleanmgr.exe": case "SystemPropertiesProtection.exe": valid = string.IsNullOrEmpty(args); break;
                default: valid = false; break;
            }
            if (!valid) throw new ArgumentException("허용되지 않은 Windows 도구 또는 실행 인수입니다.");
            return Path.Combine(Environment.SystemDirectory, exe);
        }
        internal static void Open(string exe, string args = "")
        {
            string path = Validate(exe, args);
            OperationLog.Write("Windows 도구", exe + " " + args);
            try {
                using (var process = Process.Start(new ProcessStartInfo(path, args) { UseShellExecute = false })) { }
                // Interactive Windows tools continue independently; no fabricated completion/exit code.
                OperationLog.Write("실행", "Windows 창에 작업을 넘겼습니다. 종료 코드는 수집하지 않습니다.");
            }
            catch (Exception ex) { OperationLog.Result(false, "도구 시작 실패 / 오류 코드 " + ex.HResult); throw; }
        }
    }
}
