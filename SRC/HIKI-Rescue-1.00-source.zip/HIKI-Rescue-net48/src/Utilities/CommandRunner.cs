using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace HikiRescue
{
    internal sealed class CommandResult
    {
        public int Code;
        public string Output;
        public CommandResult(int code, string output) { Code = code; Output = output; }
    }
    internal interface ICommandRunner
    {
        Task<CommandResult> Run(string exe, string args, string input, bool unicode, Action<string> output);
    }
    internal sealed class CommandRunner : ICommandRunner
    {
        public async Task<CommandResult> Run(string exe, string args, string input, bool unicode, Action<string> output)
        {
            var encoding = unicode ? Encoding.Unicode : Encoding.GetEncoding(CultureInfo.CurrentCulture.TextInfo.OEMCodePage);
            var info = new ProcessStartInfo(WindowsTools.Validate(exe, args), args) {
                UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true,
                RedirectStandardError = true, RedirectStandardInput = input != null,
                StandardOutputEncoding = encoding, StandardErrorEncoding = encoding
            };
            using (var process = new Process { StartInfo = info })
            {
                OperationLog.Write("Windows 도구", exe + " " + args);
                process.Start();
                var buffer = new StringBuilder();
                var sync = new object();
                Action<string> onLine = delegate(string line) {
                    lock (sync) {
                        if (buffer.Length < 524288) buffer.AppendLine(line);
                        if (output != null) output(line);
                    }
                };
                var stdout = Pump(process.StandardOutput, line => { OperationLog.Write("stdout", line); onLine(line); });
                var stderr = Pump(process.StandardError, line => { OperationLog.Write("stderr", line); onLine(line); });
                if (input != null) {
                    try { await process.StandardInput.WriteAsync(input); process.StandardInput.Close(); }
                    catch (IOException) { /* The command may exit before consuming stdin. */ }
                }
                await Task.WhenAll(stdout, stderr, Task.Run(() => process.WaitForExit()));
                OperationLog.Write("종료 코드", exe + ": " + process.ExitCode);
                return new CommandResult(process.ExitCode, buffer.ToString());
            }
        }
        internal static async Task Pump(StreamReader reader, Action<string> output)
        {
            char[] chars = new char[1024];
            var line = new StringBuilder();
            int count;
            while ((count = await reader.ReadAsync(chars, 0, chars.Length)) != 0) {
                for (int i = 0; i < count; i++) {
                    char c = chars[i];
                    if (c == '\r' || c == '\n' || line.Length >= 4096) {
                        if (line.Length > 0) { output(line.ToString()); line.Clear(); }
                    }
                    else if (c != '\0' && c != '\b') line.Append(c);
                }
            }
            if (line.Length > 0) output(line.ToString());
        }
    }
}
