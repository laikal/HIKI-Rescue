using System.Reflection;
using System.Runtime.InteropServices;


[assembly: AssemblyTitle("HIKI Rescue")]
[assembly: AssemblyDescription("Windows Recovery & Repair Utility")]
[assembly: AssemblyProduct("HIKI Rescue")]
[assembly: AssemblyCompany("Eltax")]
[assembly: AssemblyCopyright("Copyright © Eltax")]
[assembly: AssemblyMetadata("Author", "Eltax")]
[assembly: AssemblyMetadata("Developer", "Eltax")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.00")]
[assembly: ComVisible(false)]
namespace HikiRescue
{
    internal static class Metadata
    {
        public const string Name = "HIKI Rescue";
        public const string Version = "1.00";
        public const string Creator = "Eltax";
        public const string Recipient = "Hikimori Neko";
        public const string Copyright = "Copyright © Eltax";
    }
}

