using System;
using System.Windows.Forms;

namespace HikiRescue
{
    internal static class Program
    {
        [STAThread]
        private static void Main(string[] args)
        {
            bool administrator = Recovery.IsAdmin;
            NativeRestore.InitializeSecurity();
            RunUi(administrator, args);
        }
        [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
        private static void RunUi(bool administrator, string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            if (!Startup.EnterMain(administrator, args)) return;
            // No startup argument can trigger a repair; operations originate only from UI buttons.
            Application.Run(new MainForm());
        }
    }
}
