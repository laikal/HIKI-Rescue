using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using Microsoft.Win32;

namespace HikiRescue
{
    internal sealed class RegistryValueData
    {
        public string Name;
        public RegistryValueKind Kind;
        public object Value;
    }
    internal sealed class RegistryNode
    {
        public string Name;
        public readonly List<RegistryValueData> Values = new List<RegistryValueData>();
        public readonly List<RegistryNode> Children = new List<RegistryNode>();
    }
    internal interface IDisplayRegistry
    {
        RegistryNode Read(string name);
        void Delete(string name);
    }
    internal sealed class DisplayRegistry : IDisplayRegistry
    {
        private static void CheckName(string name)
        {
            if (!Recovery.CacheNames.Contains(name, StringComparer.Ordinal)) throw new ArgumentException("허용되지 않은 캐시 항목입니다.");
        }
        public RegistryNode Read(string name)
        {
            CheckName(name);
            using (var machine = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64))
            using (var key = machine.OpenSubKey(Recovery.GraphicsRoot + name, false))
                return key == null ? null : Capture(key, name);
        }
        private static RegistryNode Capture(RegistryKey key, string name)
        {
            var result = new RegistryNode { Name = name };
            foreach (string value in key.GetValueNames().OrderBy(v => v, StringComparer.Ordinal)) {
                var kind = key.GetValueKind(value);
                object data = key.GetValue(value, null, RegistryValueOptions.DoNotExpandEnvironmentNames);
                if (data == null) throw new IOException("백업 중 레지스트리 값이 변경되었습니다.");
                result.Values.Add(new RegistryValueData { Name = value, Kind = kind, Value = data });
            }
            foreach (string child in key.GetSubKeyNames().OrderBy(v => v, StringComparer.Ordinal))
                using (var nested = key.OpenSubKey(child, false)) {
                    if (nested == null) throw new IOException("백업 중 레지스트리 키가 변경되었습니다.");
                    result.Children.Add(Capture(nested, child));
                }
            return result;
        }
        public void Delete(string name)
        {
            CheckName(name);
            using (var machine = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64))
            using (var parent = machine.OpenSubKey(Recovery.GraphicsRoot.TrimEnd('\\'), true)) {
                if (parent == null) throw new IOException("디스플레이 캐시 경로가 없습니다.");
                parent.DeleteSubKeyTree(name, true);
            }
        }
    }
    internal static class RegistryBackup
    {
        internal static string Export(string name, RegistryNode root)
        {
            if (!Recovery.CacheNames.Contains(name) || root == null || root.Name != name) throw new ArgumentException("잘못된 백업 대상입니다.");
            var result = new StringBuilder("Windows Registry Editor Version 5.00\r\n\r\n");
            WriteNode(result, "HKEY_LOCAL_MACHINE\\" + Recovery.GraphicsRoot + name, root);
            return result.ToString();
        }
        private static void WriteNode(StringBuilder text, string path, RegistryNode node)
        {
            // Never emit ambiguous/injectable .reg section or value syntax.
            if (path.IndexOfAny(new[] { '\r', '\n', ']', '\0' }) >= 0) throw new InvalidDataException("지원하지 않는 레지스트리 키 이름입니다.");
            text.Append('[').Append(path).Append("]\r\n");
            foreach (var value in node.Values.OrderBy(v => v.Name, StringComparer.Ordinal)) {
                if (value.Name.IndexOfAny(new[] { '\r', '\n', '\0' }) >= 0) throw new InvalidDataException("지원하지 않는 레지스트리 값 이름입니다.");
                text.Append(value.Name.Length == 0 ? "@" : "\"" + value.Name.Replace("\\", "\\\\").Replace("\"", "\\\"") + "\"").Append('=');
                string prefix;
                byte[] bytes;
                switch (value.Kind) {
                    case RegistryValueKind.String: prefix = "hex(1):"; bytes = Encoding.Unicode.GetBytes((string)value.Value + "\0"); break;
                    case RegistryValueKind.ExpandString: prefix = "hex(2):"; bytes = Encoding.Unicode.GetBytes((string)value.Value + "\0"); break;
                    case RegistryValueKind.MultiString: prefix = "hex(7):"; bytes = Encoding.Unicode.GetBytes(string.Join("\0", (string[])value.Value) + "\0\0"); break;
                    case RegistryValueKind.Binary: prefix = "hex:"; bytes = (byte[])value.Value; break;
                    case RegistryValueKind.None: prefix = "hex(0):"; bytes = (byte[])value.Value; break;
                    case RegistryValueKind.QWord: prefix = "hex(b):"; bytes = BitConverter.GetBytes((long)value.Value); break;
                    case RegistryValueKind.DWord:
                        text.Append("dword:").Append(unchecked((uint)(int)value.Value).ToString("x8", CultureInfo.InvariantCulture)).Append("\r\n"); continue;
                    default: throw new InvalidDataException("지원하지 않는 레지스트리 형식이므로 삭제하지 않습니다.");
                }
                text.Append(prefix);
                for (int i = 0; i < bytes.Length; i++) {
                    if (i > 0) { text.Append(','); if (i % 24 == 0) text.Append("\\\r\n  "); }
                    text.Append(bytes[i].ToString("x2", CultureInfo.InvariantCulture));
                }
                text.Append("\r\n");
            }
            text.Append("\r\n");
            foreach (var child in node.Children.OrderBy(n => n.Name, StringComparer.Ordinal)) {
                if (child.Name.Contains("\\")) throw new InvalidDataException("잘못된 하위 키 이름입니다.");
                WriteNode(text, path + "\\" + child.Name, child);
            }
        }
        internal static void SaveAndVerify(string path, string contents)
        {
            byte[] bytes = Encoding.Unicode.GetPreamble().Concat(Encoding.Unicode.GetBytes(contents)).ToArray();
            using (var stream = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None)) {
                stream.Write(bytes, 0, bytes.Length);
                stream.Flush(true);
            }
            if (!File.ReadAllBytes(path).SequenceEqual(bytes)) throw new IOException("레지스트리 백업 파일 검증에 실패했습니다.");
        }
    }
    internal sealed class DisplayCacheService
    {
        private readonly IDisplayRegistry registry;
        internal DisplayCacheService(IDisplayRegistry registry) { this.registry = registry; }
        internal string Reset(string folder, Action<string> output)
        {
            Directory.CreateDirectory(folder);
            var results = new List<string>();
            int changed = 0, failures = 0;
            foreach (string name in Recovery.CacheNames) {
                try {
                    var snapshot = registry.Read(name);
                    if (snapshot == null) { results.Add(name + ": 항목 없음 (건너뜀)"); continue; }
                    string contents = RegistryBackup.Export(name, snapshot);
                    string path = Path.Combine(folder, name + ".reg");
                    RegistryBackup.SaveAndVerify(path, contents);
                    // Recheck after disk I/O. If the display configuration changed, keep the key untouched.
                    var current = registry.Read(name);
                    if (current == null || RegistryBackup.Export(name, current) != contents) throw new IOException("백업 중 내용이 변경되어 삭제하지 않았습니다.");
                    OperationLog.Write("레지스트리 백업", path);
                    registry.Delete(name);
                    OperationLog.Write("레지스트리 삭제", "HKLM\\" + Recovery.GraphicsRoot + name);
                    changed++; results.Add(name + ": 백업 검증 및 초기화 완료");
                }
                catch (Exception ex) {
                    failures++;
                    results.Add(name + ": 처리 실패 — " + ex.Message);
                    OperationLog.Write("레지스트리 오류", name + ": " + ex.Message + " / " + ex.HResult);
                }
            }
            string summary = string.Join("\r\n", results) + "\r\n\r\n초기화 완료: " + changed + " / 3\r\n백업 위치: " + folder +
                (changed > 0 ? "\r\nWindows를 재부팅해야 적용됩니다. 주 모니터·배치·해상도·배율을 다시 설정해야 할 수 있습니다." : "\r\n초기화된 항목이 없습니다.");
            OperationLog.Result(failures == 0, summary);
            output(summary);
            return summary;
        }
    }
}
