using System;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;

namespace HikiRescue
{
    internal sealed class DiagnosticFailure : Exception
    {
        public readonly int Code;
        public DiagnosticFailure(string message, int code) : base(message) { Code = code; }
    }
    internal sealed class DiagnosticTools
    {
        private readonly ICommandRunner runner;
        private readonly Action<string, string> launch;
        public DiagnosticTools(ICommandRunner runner, Action<string, string> launch)
        { this.runner = runner; this.launch = launch; }
        public DiagnosticTools() : this(new CommandRunner(), delegate(string exe, string args) {
            WindowsTools.Open(exe, args);
        }) { }
        public static bool IsViewer(string action)
        { return action == "reliability" || action == "memory" || action == "pcinfo" || action == "cleanup"; }
        public string Open(string action)
        {
            string exe, args = "", error, success;
            switch (action) {
                case "reliability": exe = "perfmon.exe"; args = "/rel"; error = "Windows 문제 기록을 열 수 없습니다."; success = "Windows 문제 기록을 열었습니다."; break;
                case "memory": exe = "mdsched.exe"; error = "Windows 메모리 진단을 실행할 수 없습니다."; success = "Windows 메모리 진단을 열었습니다. 검사 시점은 Windows 창에서 직접 선택하십시오."; break;
                case "pcinfo": exe = "msinfo32.exe"; error = "Windows 시스템 정보를 열 수 없습니다."; success = "Windows 시스템 정보를 열었습니다."; break;
                case "cleanup": exe = "cleanmgr.exe"; error = "Windows 디스크 정리를 실행할 수 없습니다."; success = "Windows 디스크 정리를 열었습니다. 정리할 항목은 Windows 창에서 직접 선택하십시오."; break;
                default: throw new ArgumentException("지원하지 않는 기능입니다.");
            }
            try { launch(exe, args); }
            catch (Exception ex) {
                var native = ex as System.ComponentModel.Win32Exception;
                throw new DiagnosticFailure(error, native == null ? ex.HResult : native.NativeErrorCode);
            }
            return success;
        }
        public async Task<string> FlushDns()
        {
            try {
                // Only clear the resolver cache. No network configuration reset is part of this operation.
                var result = await runner.Run("ipconfig.exe", "/flushdns", null, false, null);
                if (result.Code != 0) throw new DiagnosticFailure("DNS 캐시 초기화에 실패했습니다.", result.Code);
                return "DNS 캐시를 초기화했습니다.";
            }
            catch (DiagnosticFailure) { throw; }
            catch (Exception ex) {
                var native = ex as System.ComponentModel.Win32Exception;
                throw new DiagnosticFailure("DNS 캐시 초기화에 실패했습니다.", native == null ? ex.HResult : native.NativeErrorCode);
            }
        }
    }
}
