using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Management;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using Microsoft.Win32;

namespace HikiRescue
{
    internal sealed class RestorePointRecord
    {
        public long Sequence;
        public string Description;
        public DateTime Created;
        public string SuccessMessage { get { return "복원 지점이 생성되었습니다.\r\n\r\n" + Description; } }
        public string StatusMessage { get { return "최근 복원 지점: " + Created.ToString("yyyy-MM-dd HH:mm:ss") + "\r\nHIKI Restore"; } }
    }
    internal enum ProtectionState { Enabled, Disabled, Unknown }
    internal sealed class FrequencyState
    {
        public bool Exists;
        // Registry DWORD is exposed by .NET as a signed Int32; preserve all 32 bits.
        public int Value;
        public bool SameAs(FrequencyState other) { return Exists == other.Exists && (!Exists || Value == other.Value); }
    }
    internal sealed class RestoreFailure : Exception
    {
        public readonly uint Code;
        public readonly string Stage;
        public readonly bool ProtectionDisabled;
        public RestoreFailure(string message, uint code, string stage, bool disabled = false)
            : base(message + "\r\n오류 코드: " + code.ToString(CultureInfo.InvariantCulture) + " (0x" + code.ToString("X8") + ")")
        { Code = code; Stage = stage; ProtectionDisabled = disabled; }
        public static RestoreFailure From(Exception ex, string stage)
        {
            var known = ex as RestoreFailure;
            if (known != null) return known;
            var win32 = ex as Win32Exception;
            uint code = win32 == null ? unchecked((uint)ex.HResult) : unchecked((uint)win32.NativeErrorCode);
            return new RestoreFailure("복원 지점을 만들지 못했습니다.", code, stage);
        }
        public static RestoreFailure Api(uint code, string stage)
        {
            string message;
            uint win32 = (code & 0xFFFF0000) == 0x80070000 ? code & 0xFFFF : code;
            if (win32 == 1058) message = "시스템 보호가 비활성화되어 있어 복원 지점을 만들 수 없습니다.";
            else if (win32 == 112 || code == 0x8004231F) message = "저장 공간 또는 섀도 복사본 저장 공간이 부족합니다. 여유 공간과 시스템 보호의 디스크 사용량을 확인하십시오.";
            else if (win32 == 5) message = "복원 지점을 만들 권한이 없습니다. 관리자 권한과 Windows 보안 정책을 확인하십시오.";
            else if (win32 == 10) message = "안전 모드에서는 복원 지점을 만들 수 없습니다.";
            else if (win32 == 1460 || code == 0x80042316) message = "다른 복원 또는 VSS 작업이 진행 중이거나 응답 시간이 초과되었습니다. 잠시 후 다시 시도하십시오.";
            else if ((code & 0xFFFFFF00) == 0x80042300 || (code & 0xFFFFFF00) == 0x800423F0)
                message = "볼륨 섀도 복사본(VSS) 오류로 복원 지점을 만들 수 없습니다. 로그의 오류 코드와 Windows 이벤트 뷰어를 확인하십시오.";
            else message = "Windows 시스템 복원 API 호출에 실패했습니다.";
            return new RestoreFailure(message, code, stage, win32 == 1058);
        }
    }
    internal interface IRestorePlatform
    {
        bool IsAdmin { get; }
        ProtectionState CheckProtection();
        IList<RestorePointRecord> ListPoints();
        FrequencyState ReadFrequency();
        void WriteFrequency(FrequencyState state);
        long CreateNative(string description, Action<string> log);
        DateTime Now { get; }
        void WaitForList();
    }
    internal sealed class RestorePointService
    {
        private readonly IRestorePlatform platform;
        public RestorePointService(IRestorePlatform platform) { this.platform = platform; }
        internal static string SafeLog(string text)
        {
            string[] blocked = { "CLIXML", "System.Management.Automation", "PSCUSTOMOBJECT", "ProgressRecord", "<Objs", "<?xml" };
            if (text != null && blocked.Any(x => text.IndexOf(x, StringComparison.OrdinalIgnoreCase) >= 0))
                return "직렬화된 내부 출력은 표시하지 않습니다.";
            if (text != null && Regex.IsMatch(text, @"<[/!?A-Za-z][^>]*>")) return "직렬화된 내부 출력은 표시하지 않습니다.";
            return (text ?? "").Replace("\0", "");
        }
        public RestorePointRecord Create(Action<string> output)
        {
            Action<string> log = s => {
                string text = SafeLog(s);
                OperationLog.Write("시스템 복원", text);
                output("[" + platform.Now.ToString("HH:mm:ss") + "] " + text);
            };
            try {
                if (!platform.IsAdmin) throw RestoreFailure.Api(5, "관리자 권한 확인");
                // The frequency is machine-wide; serialize HIKI restore creation across user sessions.
                using (var gate = new Mutex(false, @"Global\HikiRescue.RestorePointFrequency")) {
                    bool acquired;
                    try { acquired = gate.WaitOne(0); } catch (AbandonedMutexException) { acquired = true; }
                    if (!acquired) throw new RestoreFailure("다른 HIKI Rescue 창에서 복원 지점을 생성하고 있습니다.", 170, "동시 실행 확인");
                    try { return CreateCore(log); }
                    finally { gate.ReleaseMutex(); }
                }
            }
            catch (Exception ex) {
                var failure = RestoreFailure.From(ex, "복원 지점 생성");
                log("오류 단계: " + failure.Stage + "; 오류 코드: " + failure.Code + " (0x" + failure.Code.ToString("X8") + ")");
                // Exception messages may originate in WMI; sanitize before displaying diagnostic text.
                log("기술 상세: " + SafeLog(ex.Message));
                log("복원 지점 생성 실패");
                throw failure;
            }
        }
        private RestorePointRecord CreateCore(Action<string> log)
        {
            log("복원 지점 생성을 시작했습니다.");
            ProtectionState protection;
            try { protection = platform.CheckProtection(); }
            catch (Exception ex) { throw RestoreFailure.From(ex, "시스템 드라이브 보호 상태 조회"); }
            if (protection == ProtectionState.Disabled) throw RestoreFailure.Api(1058, "시스템 드라이브 보호 상태 조회");
            if (protection != ProtectionState.Enabled)
                throw new RestoreFailure("시스템 드라이브의 보호 상태를 확인할 수 없습니다. Windows 시스템 보호 설정을 확인하십시오.", 13, "시스템 드라이브 보호 상태 조회");
            IList<RestorePointRecord> before;
            try { before = platform.ListPoints(); }
            catch (Exception ex) { throw RestoreFailure.From(ex, "생성 전 복원 지점 목록 조회"); }
            long highest = before.Count == 0 ? 0 : before.Max(p => p.Sequence);
            string description = "HIKI Restore - " + platform.Now.ToString("yyyy-MM-dd HH-mm-ss", CultureInfo.InvariantCulture);
            FrequencyState original;
            try { original = platform.ReadFrequency(); }
            catch (Exception ex) { throw RestoreFailure.From(ex, "생성 제한 원래 설정 읽기"); }
            RestorePointRecord verified = null;
            RestoreFailure error = null;
            try {
                // finally also runs if the write succeeds but its subsequent verification fails.
                platform.WriteFrequency(new FrequencyState { Exists = true, Value = 0 });
                if (!platform.ReadFrequency().SameAs(new FrequencyState { Exists = true, Value = 0 }))
                    throw new RestoreFailure("24시간 생성 제한을 임시 해제하지 못했습니다.", 13, "임시 설정 검증");
                log("24시간 생성 제한을 임시 해제했습니다.");
                long nativeSequence = platform.CreateNative(description, log);
                log("Windows System Restore API 호출 완료 (번호 " + nativeSequence + ")");
                // API success alone is insufficient: exact name, a newer number AND the API's number must agree.
                for (int attempt = 0; attempt < 10; attempt++) {
                    var after = platform.ListPoints();
                    verified = after.FirstOrDefault(p => p.Sequence > highest && p.Sequence == nativeSequence && p.Description == description);
                    if (verified != null) break;
                    if (attempt < 9) platform.WaitForList();
                }
                if (verified == null) throw new RestoreFailure("새 복원 지점이 확인되지 않았습니다. Windows가 생성을 건너뛰었거나 목록 반영이 지연되었을 수 있습니다.", 1168, "생성 후 목록 검증");
                log("새 복원 지점 확인 완료 (번호 " + verified.Sequence + ", " + verified.Description + ")");
            }
            catch (Exception ex) { error = RestoreFailure.From(ex, "복원 지점 생성 및 검증"); }
            finally {
                Exception rollbackError = null;
                for (int attempt = 0; attempt < 3; attempt++) {
                    try {
                        platform.WriteFrequency(original);
                        if (!platform.ReadFrequency().SameAs(original)) throw new InvalidOperationException("원상복구 후 값이 작업 전 상태와 다릅니다.");
                        rollbackError = null; break;
                    }
                    catch (Exception ex) { rollbackError = ex; }
                }
                if (rollbackError == null) log("생성 제한 설정을 원래 상태로 복구했습니다. (" + (original.Exists ? "DWORD " + unchecked((uint)original.Value) : "값 없음") + ")");
                else {
                    if (error != null) log("원래 작업 오류: " + error.Stage + "; " + error.Code);
                    var failure = RestoreFailure.From(rollbackError, "생성 제한 원상복구");
                    log("원상복구 실패. " + WindowsRestorePlatform.FrequencyName + ": 원래 상태=" + (original.Exists ? unchecked((uint)original.Value).ToString() : "값 없음"));
                    log("설정 위치: HKLM\\" + WindowsRestorePlatform.SettingsPath);
                    error = new RestoreFailure((verified == null ? "복원 지점 생성 작업 후 " : "새 복원 지점은 확인되었으나 ") +
                        "생성 제한 설정을 원래 상태로 복구하지 못했습니다. 로그의 원래 상태를 확인하여 설정을 복구하십시오.", failure.Code, "생성 제한 원상복구");
                }
            }
            if (error != null) throw error;
            log("복원 지점 생성 성공");
            return verified;
        }
    }
    internal sealed class WindowsRestorePlatform : IRestorePlatform
    {
        internal const string SettingsPath = @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore";
        internal const string FrequencyName = "SystemRestorePointCreationFrequency";
        internal const string ClientsPath = @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\SPP\Clients";
        internal const string RestoreClient = "{09F7EDC5-294E-4180-AF6A-FB0E6A0E9513}";
        private static RegistryView View { get { return Environment.Is64BitOperatingSystem ? RegistryView.Registry64 : RegistryView.Registry32; } }
        public bool IsAdmin { get { return Recovery.IsAdmin; } }
        public DateTime Now { get { return DateTime.Now; } }
        public void WaitForList() { Thread.Sleep(1000); }
        public ProtectionState CheckProtection()
        {
            using (var machine = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, View)) {
                using (var policy = machine.OpenSubKey(@"SOFTWARE\Policies\Microsoft\Windows NT\SystemRestore")) {
                    if (policy != null && Convert.ToInt32(policy.GetValue("DisableSR", 0), CultureInfo.InvariantCulture) == 1) return ProtectionState.Disabled;
                }
                using (var settings = machine.OpenSubKey(SettingsPath)) {
                    if (settings != null && Convert.ToInt32(settings.GetValue("DisableSR", 0), CultureInfo.InvariantCulture) == 1) return ProtectionState.Disabled;
                    object interval = settings == null ? null : settings.GetValue("RPSessionInterval");
                    if (interval is int && (int)interval == 0) return ProtectionState.Disabled;
                }
                string root = Path.GetPathRoot(Environment.SystemDirectory);
                var volume = new StringBuilder(1024);
                if (!NativeRestore.GetVolumeNameForVolumeMountPoint(root, volume, volume.Capacity)) throw new Win32Exception(Marshal.GetLastWin32Error());
                // Check the actual system volume in SPP's System Restore client registration.
                // Do not infer protection from old restore points, VSS storage, or SRInitDone.
                using (var clients = machine.OpenSubKey(ClientsPath)) {
                    if (clients == null) return ProtectionState.Disabled;
                    object value = clients.GetValue(RestoreClient, null, RegistryValueOptions.DoNotExpandEnvironmentNames);
                    if (value == null) return ProtectionState.Disabled;
                    var entries = value as string[];
                    if (entries == null) return ProtectionState.Unknown;
                    return IsRegisteredVolume(entries, volume.ToString()) ? ProtectionState.Enabled : ProtectionState.Disabled;
                }
            }
        }
        internal static bool IsRegisteredVolume(string[] entries, string volume)
        {
            return entries.Any(v => Regex.Matches(v, @"\\\\\?\\Volume\{[0-9A-Fa-f-]+\}\\?")
                .Cast<Match>().Any(m => string.Equals(m.Value.TrimEnd('\\'), volume.TrimEnd('\\'), StringComparison.OrdinalIgnoreCase)));
        }
        public IList<RestorePointRecord> ListPoints()
        {
            NativeRestore.RequireSecurity();
            var list = new List<RestorePointRecord>();
            var scope = new ManagementScope(@"\\.\root\default", new ConnectionOptions { EnablePrivileges = true,
                Impersonation = ImpersonationLevel.Impersonate, Authentication = AuthenticationLevel.PacketPrivacy, Timeout = TimeSpan.FromSeconds(30) });
            using (var search = new ManagementObjectSearcher(scope, new ObjectQuery("SELECT SequenceNumber, Description, CreationTime FROM SystemRestore"),
                new EnumerationOptions { ReturnImmediately = false, Timeout = TimeSpan.FromSeconds(30) }))
            using (var results = search.Get()) {
                foreach (ManagementObject item in results) using (item) {
                    list.Add(new RestorePointRecord { Sequence = Convert.ToInt64(item["SequenceNumber"], CultureInfo.InvariantCulture),
                        Description = Convert.ToString(item["Description"], CultureInfo.InvariantCulture),
                        Created = ManagementDateTimeConverter.ToDateTime(Convert.ToString(item["CreationTime"], CultureInfo.InvariantCulture)) });
                }
            }
            return list;
        }
        public FrequencyState ReadFrequency()
        {
            using (var machine = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, View))
            using (var key = machine.OpenSubKey(SettingsPath)) {
                if (key == null || !key.GetValueNames().Contains(FrequencyName, StringComparer.OrdinalIgnoreCase)) return new FrequencyState();
                if (key.GetValueKind(FrequencyName) != RegistryValueKind.DWord)
                    throw new RestoreFailure("생성 제한 설정의 형식이 DWORD가 아니므로 변경하지 않았습니다.", 13, "생성 제한 원래 설정 읽기");
                return new FrequencyState { Exists = true, Value = (int)key.GetValue(FrequencyName) };
            }
        }
        public void WriteFrequency(FrequencyState state)
        {
            using (var machine = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, View)) {
                if (state.Exists) {
                    using (var key = machine.CreateSubKey(SettingsPath)) { key.SetValue(FrequencyName, state.Value, RegistryValueKind.DWord); key.Flush(); }
                }
                else using (var key = machine.OpenSubKey(SettingsPath, true)) {
                    if (key != null) { key.DeleteValue(FrequencyName, false); key.Flush(); }
                }
            }
        }
        public long CreateNative(string description, Action<string> log) { return NativeRestore.Create(description, log); }
    }
}

