using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace HikiRescue
{
    internal sealed class Recovery
    {
        private readonly ICommandRunner runner;
        public const string GraphicsRoot = @"SYSTEM\CurrentControlSet\Control\GraphicsDrivers\";
        public static readonly string[] CacheNames = { "Configuration", "Connectivity", "ScaleFactors" };
        public Recovery(ICommandRunner runner) { this.runner = runner; }
        public static bool IsAdmin {
            get {
                using (var identity = System.Security.Principal.WindowsIdentity.GetCurrent())
                    return new System.Security.Principal.WindowsPrincipal(identity).IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator);
            }
        }
        public static int? ParseProgress(string line)
        {
            Match m = Regex.Match(line, @"(?<![\d.,])(\d{1,3}(?:[.,]\d+)?)\s*%");
            double value;
            if (m.Success && double.TryParse(m.Groups[1].Value.Replace(',', '.'), NumberStyles.Float,
                CultureInfo.InvariantCulture, out value) && value >= 0 && value <= 100) return (int)value;
            return null;
        }
        public async Task<string> Repair(Action<string> output, Action<string> stage)
        {
            stage("1 / 2   Windows 이미지 복구 중 (DISM)");
            var dism = await runner.Run("dism.exe", "/Online /Cleanup-Image /RestoreHealth", null, false, output);
            if (dism.Code == 3010) return "DISM이 재부팅을 요청했습니다. 재부팅 후 Windows 점검 및 복구를 다시 실행하십시오. SFC는 아직 실행하지 않았습니다.";
            if (dism.Code != 0) throw new InvalidOperationException("DISM 실패 (종료 코드 " + dism.Code + "). SFC는 실행하지 않았습니다. 아래 출력과 Windows\\Logs\\DISM\\dism.log를 확인하십시오.");
            stage("2 / 2   Windows 시스템 파일 검사 중 (SFC)");
            var sfc = await runner.Run("sfc.exe", "/scannow", null, true, output);
            if (sfc.Code != 0) throw new InvalidOperationException("SFC 종료 코드: " + sfc.Code + ". 복구 결과는 아래 출력과 Windows\\Logs\\CBS\\CBS.log를 확인하십시오.");
            return "DISM 및 SFC 실행이 끝났습니다. 손상 발견·복구 여부는 아래 SFC 결과를 확인하십시오. 재부팅이 필요하다는 안내가 있으면 작업을 저장한 뒤 재부팅하십시오.";
        }
        public Task<RestorePointRecord> CreateRestorePoint(Action<string> output)
        {
            return Task.Run(() => new RestorePointService(new WindowsRestorePlatform()).Create(output));
        }
        public static bool HasScheduledScan(string[] entries, string drive)
        {
            // Match an explicit /r job for this volume; the default 'autocheck autochk *' is not evidence.
            return entries != null && entries.Any(x => Regex.IsMatch(x,
                @"^\s*autocheck\s+autochk\s+/r\s+\\\?\?\\" + Regex.Escape(drive) + @"\s*$", RegexOptions.IgnoreCase));
        }
        public async Task<string> ScheduleDisk(Action<string> output)
        {
            string drive = Path.GetPathRoot(Environment.SystemDirectory).TrimEnd('\\');
            var result = await runner.Run("chkdsk.exe", drive + " /R", "Y\r\n", false, output);
            string[] entries;
            using (var hklm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64))
            using (var key = hklm.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Session Manager"))
                entries = key == null ? null : key.GetValue("BootExecute") as string[];
            if (!HasScheduledScan(entries, drive))
                throw new InvalidOperationException("디스크 검사 예약을 확인하지 못했습니다 (종료 코드 " + result.Code + "). Windows 언어별 확인 입력 또는 정책 문제일 수 있습니다. 관리자 명령 프롬프트에서 chkdsk " + drive + " /R 을 실행하고 표시되는 예약 질문에 직접 답하십시오.");
            return drive + " 정밀 검사가 다음 재부팅에 예약되어 있습니다. 검사에는 수 시간이 걸릴 수 있습니다.";
        }
        public Task<string> ResetCache(Action<string> output)
        {
            string folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "HIKI Rescue", "Backups", DateTime.Now.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N").Substring(0, 8));
            return Task.Run(() => new DisplayCacheService(new DisplayRegistry()).Reset(folder, output));
        }
    }
}