using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Management;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using Microsoft.Win32;

namespace HikiRescue
{
    internal static class NativeRestore
    {
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode, Pack = 1)]
        internal struct RestoreInfo {
            public uint EventType, PointType;
            public long Sequence;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)] public string Description;
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        internal struct RestoreStatus { public uint Status; public long Sequence; }
        [UnmanagedFunctionPointer(CallingConvention.Winapi, CharSet = CharSet.Unicode)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private delegate bool SetRestorePoint(ref RestoreInfo info, out RestoreStatus status);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern IntPtr LoadLibraryEx(string path, IntPtr file, uint flags);
        [DllImport("kernel32.dll", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)] private static extern IntPtr GetProcAddress(IntPtr module, string name);
        [DllImport("kernel32.dll")] private static extern bool FreeLibrary(IntPtr module);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] internal static extern bool GetVolumeNameForVolumeMountPoint(string root, StringBuilder name, int size);
        [DllImport("ole32.dll")] private static extern int CoInitializeEx(IntPtr reserved, uint mode);
        [DllImport("ole32.dll")] private static extern void CoUninitialize();
        [DllImport("ole32.dll")] private static extern int CoInitializeSecurity(IntPtr descriptor, int count, IntPtr services, IntPtr reserved,
            uint authentication, uint impersonation, IntPtr authList, uint capabilities, IntPtr reserved3);
        [DllImport("advapi32.dll", SetLastError = true)] private static extern bool InitializeSecurityDescriptor(IntPtr descriptor, uint revision);
        [DllImport("advapi32.dll", SetLastError = true)] private static extern bool SetSecurityDescriptorOwner(IntPtr descriptor, IntPtr owner, bool defaulted);
        [DllImport("advapi32.dll", SetLastError = true)] private static extern bool SetSecurityDescriptorGroup(IntPtr descriptor, IntPtr group, bool defaulted);
        [DllImport("advapi32.dll", SetLastError = true)] private static extern bool SetSecurityDescriptorDacl(IntPtr descriptor, bool present, IntPtr acl, bool defaulted);
        private static Exception securityError;
        private static bool initialized;
        internal static void InitializeSecurity()
        {
            if (initialized) return;
            initialized = true;
            // Must run before Windows Forms/OLE or WMI can initialize process-wide COM security.
            int hr = CoInitializeEx(IntPtr.Zero, 2);
            bool uninitialize = hr >= 0;
            try {
                if (hr < 0) Marshal.ThrowExceptionForHR(hr);
                var admins = new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid, null);
                var acl = new RawAcl(2, 5);
                var sids = new List<SecurityIdentifier> { admins,
                    new SecurityIdentifier(WellKnownSidType.LocalSystemSid, null),
                    new SecurityIdentifier(WellKnownSidType.LocalServiceSid, null),
                    new SecurityIdentifier(WellKnownSidType.NetworkServiceSid, null) };
                using (var identity = WindowsIdentity.GetCurrent()) sids.Add(identity.User);
                foreach (var sid in sids) acl.InsertAce(acl.Count, new CommonAce(AceFlags.None, AceQualifier.AccessAllowed, 3, sid, false, null));
                byte[] aclBytes = new byte[acl.BinaryLength]; acl.GetBinaryForm(aclBytes, 0);
                byte[] ownerBytes = new byte[admins.BinaryLength]; admins.GetBinaryForm(ownerBytes, 0);
                IntPtr descriptor = Marshal.AllocHGlobal(IntPtr.Size == 8 ? 40 : 20);
                IntPtr aclPtr = Marshal.AllocHGlobal(aclBytes.Length), ownerPtr = Marshal.AllocHGlobal(ownerBytes.Length);
                try {
                    Marshal.Copy(aclBytes, 0, aclPtr, aclBytes.Length); Marshal.Copy(ownerBytes, 0, ownerPtr, ownerBytes.Length);
                    if (!InitializeSecurityDescriptor(descriptor, 1) || !SetSecurityDescriptorOwner(descriptor, ownerPtr, false) ||
                        !SetSecurityDescriptorGroup(descriptor, ownerPtr, false) || !SetSecurityDescriptorDacl(descriptor, true, aclPtr, false))
                        throw new Win32Exception(Marshal.GetLastWin32Error());
                    // Local callbacks for service accounts and current user; never a null/world-access DACL.
                    hr = CoInitializeSecurity(descriptor, -1, IntPtr.Zero, IntPtr.Zero, 6, 3, IntPtr.Zero, 0x3000, IntPtr.Zero);
                    if (hr < 0) Marshal.ThrowExceptionForHR(hr);
                }
                finally { Marshal.FreeHGlobal(descriptor); Marshal.FreeHGlobal(aclPtr); Marshal.FreeHGlobal(ownerPtr); }
            }
            catch (Exception ex) { securityError = ex; }
            finally { if (uninitialize) CoUninitialize(); }
        }
        internal static void RequireSecurity()
        {
            if (!initialized) throw new RestoreFailure("Windows 시스템 복원 API 초기화가 필요합니다.", 0x800401F0, "COM 보안 초기화");
            if (securityError != null) throw RestoreFailure.From(securityError, "COM 보안 초기화");
        }
        internal static long Create(string description, Action<string> log)
        {
            RequireSecurity();
            int hr = CoInitializeEx(IntPtr.Zero, 0);
            if (hr < 0) Marshal.ThrowExceptionForHR(hr);
            IntPtr library = IntPtr.Zero;
            try {
                library = LoadLibraryEx(Path.Combine(Environment.SystemDirectory, "srclient.dll"), IntPtr.Zero, 0x800);
                if (library == IntPtr.Zero) throw new Win32Exception(Marshal.GetLastWin32Error());
                IntPtr address = GetProcAddress(library, "SRSetRestorePointW");
                if (address == IntPtr.Zero) throw new Win32Exception(Marshal.GetLastWin32Error());
                var call = (SetRestorePoint)Marshal.GetDelegateForFunctionPointer(address, typeof(SetRestorePoint));
                var info = new RestoreInfo { EventType = 100, PointType = 12, Sequence = 0, Description = description };
                RestoreStatus state;
                bool ok = call(ref info, out state);
                if (!ok || state.Status != 0) throw RestoreFailure.Api(state.Status == 0 ? 1359U : state.Status, "SRSetRestorePointW BEGIN_SYSTEM_CHANGE");
                long sequence = state.Sequence;
                info.EventType = 101; info.Sequence = sequence;
                ok = call(ref info, out state);
                if (!ok || state.Status != 0) throw RestoreFailure.Api(state.Status == 0 ? 1359U : state.Status, "SRSetRestorePointW END_SYSTEM_CHANGE");
                return sequence;
            }
            finally { if (library != IntPtr.Zero) FreeLibrary(library); CoUninitialize(); }
        }
    }
}
