using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace HikiRescue
{
    internal sealed class MainForm : Form
    {
        private readonly List<Button> actions = new List<Button>();
        private readonly Label status = Theme.Label("준비됨", 11, true);
        private readonly Label percent = Theme.Label("", 10, false);
        private readonly ProgressBar progress = new ProgressBar { Dock = DockStyle.Fill, Style = ProgressBarStyle.Continuous, Height = 8 };
        private readonly RichTextBox log = new RichTextBox { Dock = DockStyle.Fill, ReadOnly = true, DetectUrls = false,
            BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle, Font = new Font("맑은 고딕", 9F) };
        private bool busy;
        private readonly Recovery recovery = new Recovery(new CommandRunner());
        private readonly DiagnosticTools diagnostics = new DiagnosticTools();
        public MainForm()
        {
            Theme.Setup(this, "HIKI Rescue 1.00", new Size(840, 760));
            var root = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(24, 18, 24, 18), ColumnCount = 1, RowCount = 8 };
            float[] sizes = { 54, 36, 370, 47, 13, 100, 43, 31 };
            for (int i = 0; i < sizes.Length; i++) root.RowStyles.Add(new RowStyle(i == 5 ? SizeType.Percent : SizeType.Absolute, sizes[i]));
            root.Controls.Add(Theme.Label("HIKI Rescue", 25, true), 0, 0);
            root.Controls.Add(Theme.Label("Windows 기본 복구 도구를 한곳에서   ·   버전 1.00", 10, false), 0, 1);
            var cards = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 2, Margin = new Padding(0) };
            cards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50)); cards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            cards.RowStyles.Add(new RowStyle(SizeType.Percent, 50)); cards.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
            cards.Controls.Add(CreateGroup("복구", new[] { "복원 지점 만들기", "시스템 복원" }, new[] { "restore", "rstrui" }), 0, 0);
            cards.Controls.Add(CreateGroup("점검", new[] { "Windows 점검 및 복구", "디스크 정밀 검사", "메모리 진단" }, new[] { "repair", "disk", "memory" }), 1, 0);
            cards.Controls.Add(CreateGroup("문제 해결", new[] { "디스플레이 캐시 초기화", "DNS 캐시 초기화" }, new[] { "display", "dns" }), 0, 1);
            cards.Controls.Add(CreateGroup("관리 / 정보", new[] { "Windows 디스크 정리", "문제 기록 보기", "PC 정보 보기" }, new[] { "cleanup", "reliability", "pcinfo" }), 1, 1);
            root.Controls.Add(cards, 0, 2);
            var statusRow = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, Margin = new Padding(0) };
            statusRow.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            statusRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100)); statusRow.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 80));
            percent.TextAlign = ContentAlignment.MiddleRight; statusRow.Controls.Add(status, 0, 0); statusRow.Controls.Add(percent, 1, 0);
            root.Controls.Add(statusRow, 0, 3); root.Controls.Add(progress, 0, 4); root.Controls.Add(log, 0, 5);
            var footer = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft, Padding = new Padding(0, 5, 0, 0), Margin = new Padding(0) };
            var about = Theme.Button("프로그램 정보"); about.Width = 130; about.Click += delegate { using (var form = new AboutForm()) form.ShowDialog(this); };
            var help = Theme.Button("도움말"); help.Click += delegate { ShowHelp(0); };
            footer.Controls.Add(about); footer.Controls.Add(help); root.Controls.Add(footer, 0, 6);
            root.Controls.Add(Theme.Label("관리자 권한 : 활성   ·   중요 파일은 별도로 백업하세요.", 9, false), 0, 7);
            Controls.Add(root);
            log.Text = "실행할 기능을 선택하세요. 각 행의 ‘설명’에서 사용 방법을 확인할 수 있습니다.\r\n작업 결과와 Windows 도구의 출력이 이곳에 표시됩니다.";
            FormClosing += delegate(object sender, FormClosingEventArgs e) {
                if (busy && e.CloseReason == CloseReason.UserClosing) {
                    e.Cancel = true; MessageBox.Show(this, "작업이 진행 중입니다. 완료될 때까지 창을 열어 두십시오.", Metadata.Name, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            };
            KeyPreview = true; KeyDown += delegate(object sender, KeyEventArgs e) { if (e.KeyCode == Keys.F1) { e.Handled = true; ShowHelp(0); } };
        }
        private GroupBox CreateGroup(string title, string[] labels, string[] ids)
        {
            var group = new GroupBox { Text = title, Dock = DockStyle.Fill, Padding = new Padding(10, 7, 10, 10), Margin = new Padding(0, 0, 10, 10), ForeColor = Theme.Ink };
            var rows = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 4, Margin = new Padding(0) };
            rows.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100)); rows.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 62));
            for (int i = 0; i < 3; i++) rows.RowStyles.Add(new RowStyle(SizeType.Absolute, 46));
            rows.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            for (int i = 0; i < labels.Length; i++) {
                string name = labels[i], action = ids[i];
                var run = Theme.Button(name); run.Dock = DockStyle.Fill; run.Margin = new Padding(0, 2, 6, 5);
                run.Click += async delegate { await Execute(action); }; actions.Add(run);
                var details = Theme.Button("설명"); details.Dock = DockStyle.Fill; details.Margin = new Padding(0, 2, 0, 5);
                details.AccessibleName = name + " 설명";
                details.Click += delegate { ShowHelp(HelpForm.LoadTopics().FindIndex(t => t.Title == name)); };
                rows.Controls.Add(run, 0, i); rows.Controls.Add(details, 1, i);
            }
            group.Controls.Add(rows); return group;
        }
        private async Task ExecuteDiagnostic(string action)
        {
            busy = true; actions.ForEach(b => b.Enabled = false);
            progress.Value = 0; percent.Text = "";
            try {
                string result;
                if (action == "dns") {
                    if (MessageBox.Show(this, "Windows의 DNS 이름 조회 캐시만 지웁니다. 네트워크 설정은 변경하지 않습니다. 진행하시겠습니까?", Metadata.Name, MessageBoxButtons.OKCancel, MessageBoxIcon.Information) != DialogResult.OK) return;
                    status.Text = "DNS 캐시 초기화 중"; progress.Style = ProgressBarStyle.Marquee;
                    result = await diagnostics.FlushDns();
                }
                else result = diagnostics.Open(action);
                OperationLog.Result(true, result); Append(result); status.Text = result; percent.Text = "완료";
                if (action == "dns") MessageBox.Show(this, result, Metadata.Name, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (DiagnosticFailure ex) {
                status.Text = ex.Message; percent.Text = "오류";
                Append(ex.Message + " 오류 코드: " + ex.Code + " (0x" + unchecked((uint)ex.Code).ToString("X8") + ")");
                ShowError(ex.Message);
            }
            finally { progress.Style = ProgressBarStyle.Continuous; busy = false; actions.ForEach(b => b.Enabled = true); }
        }
        private void ShowHelp(int topic) { using (var form = new HelpForm(topic)) form.ShowDialog(this); }
        internal void ShowRestoreSuccess(RestorePointRecord point)
        {
            status.Text = point.StatusMessage;
            progress.Style = ProgressBarStyle.Continuous; progress.Value = 100; percent.Text = "완료";
        }
        private void Append(string text)
        {
            OperationLog.Write("화면 안내", text);
            if (log.TextLength > 250000) { log.Select(0, 100000); log.SelectedText = ""; }
            log.AppendText(text + "\r\n"); log.SelectionStart = log.TextLength; log.ScrollToCaret();
            var value = Recovery.ParseProgress(text);
            if (value.HasValue) { progress.Style = ProgressBarStyle.Continuous; progress.Value = value.Value; percent.Text = value + "%"; }
        }
        private static void LaunchWindows(string exe)
        {
            WindowsTools.Open(exe);
        }
        private async Task Execute(string action)
        {
            if (busy) return;
            OperationLog session = null;
            try {
                session = OperationLog.Begin(action);
                await ExecuteCore(action);
            }
            catch (Exception ex) {
                OperationLog.Result(false, "작업 오류: " + ex.Message + " / " + ex.HResult);
                ShowError("작업을 완료하지 못했습니다. " + ex.Message);
            }
            finally {
                if (session != null) {
                    session.Dispose();
                    Append("로그: " + session.FilePath);
                    if (session.WriteFailed) ShowError("로그 파일의 일부 내용을 저장하지 못했습니다. 화면의 작업 결과를 확인하십시오.");
                }
            }
        }
        private async Task ExecuteCore(string action)
        {
            if (busy) return;
            if (action == "rstrui") {
                try { LaunchWindows("rstrui.exe"); OperationLog.Result(true, "Windows 시스템 복원 창 실행"); } catch (Exception ex) { ShowError(ex.Message); }
                return;
            }
            if (!Recovery.IsAdmin) {
                ShowError(Startup.FailedMessage);
                Close();
                return;
            }
            if (DiagnosticTools.IsViewer(action) || action == "dns") { await ExecuteDiagnostic(action); return; }
            string warning = action == "restore" ? "현재 Windows 상태로 복원 지점을 만듭니다. 시스템 보호가 켜져 있어야 하며 개인 파일은 백업되지 않습니다." :
                action == "repair" ? "DISM과 SFC를 순서대로 실행합니다. 오래 걸릴 수 있고 인터넷 연결이 필요할 수 있습니다. 진행 중 강제 종료하지 마십시오." :
                action == "disk" ? "시스템 드라이브에 CHKDSK /R을 예약합니다. 다음 재부팅 시 수 시간 이상 걸릴 수 있습니다. 중요한 파일을 먼저 백업하십시오." :
                "모니터 구성 레지스트리 3개 항목을 백업한 뒤 초기화합니다. 그래픽 드라이버는 삭제하지 않습니다. 재부팅 후 주 모니터·위치·해상도·배율을 다시 설정해야 할 수 있습니다.";
            if (MessageBox.Show(this, warning + "\r\n\r\n진행하시겠습니까?", Metadata.Name, MessageBoxButtons.OKCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) != DialogResult.OK) return;
            using (var gate = new Mutex(false, @"Local\HikiRescue.RecoveryOperation")) {
                bool acquired;
                try { acquired = gate.WaitOne(0); } catch (AbandonedMutexException) { acquired = true; }
                if (!acquired) { ShowError("다른 HIKI Rescue 창에서 작업이 진행 중입니다."); return; }
                busy = true; actions.ForEach(b => b.Enabled = false); log.Clear(); percent.Text = "진행 중";
                progress.Style = ProgressBarStyle.Marquee; status.Text = "작업 준비 중…";
                var output = new Progress<string>(Append);
                Action<string> report = s => ((IProgress<string>)output).Report(s);
                try {
                    string result;
                    if (action == "repair") result = await recovery.Repair(report, s => { status.Text = s; percent.Text = "진행 중"; progress.Style = ProgressBarStyle.Marquee; progress.Value = 0; });
                    else if (action == "restore") {
                        status.Text = "복원 지점 생성 중";
                        var point = await recovery.CreateRestorePoint(report);
                        result = point.SuccessMessage;
                        ShowRestoreSuccess(point);
                    }
                    else if (action == "disk") { status.Text = "디스크 검사 예약 중"; result = await recovery.ScheduleDisk(report); }
                    else { status.Text = "디스플레이 캐시 백업 및 초기화 중"; result = await recovery.ResetCache(report); }
                    if (action != "display") OperationLog.Result(true, result);
                    Append("\r\n" + result); if (action != "restore") status.Text = "작업 결과를 확인하세요"; percent.Text = "종료";
                    progress.Style = ProgressBarStyle.Continuous; progress.Value = 100;
                    if (action == "disk") OfferRestart(result);
                    else if (action == "display" || action == "restore") MessageBox.Show(this, result, Metadata.Name, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex) {
                    status.Text = "작업을 완료하지 못했습니다"; percent.Text = "오류"; progress.Style = ProgressBarStyle.Continuous; progress.Value = 0;
                    OperationLog.Result(false, ex.Message + " / " + ex.HResult);
                    var failure = ex as RestoreFailure;
                    Append(action == "restore" ? RestorePointService.SafeLog(ex.Message) : ex.Message);
                    if (action == "restore" && failure != null && failure.ProtectionDisabled) {
                        if (MessageBox.Show(this, "시스템 보호가 비활성화되어 있습니다.\r\nWindows 시스템 보호 설정을 여시겠습니까?", Metadata.Name,
                            MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) {
                            try { LaunchWindows("SystemPropertiesProtection.exe"); } catch (Exception error) { ShowError(error.Message); }
                        }
                    }
                    else ShowError(action == "restore" ? RestorePointService.SafeLog(ex.Message) : ex.Message);
                }
                finally { busy = false; actions.ForEach(b => b.Enabled = true); gate.ReleaseMutex(); }
            }
        }
        private void ShowError(string message) { OperationLog.Result(false, message); MessageBox.Show(this, message, Metadata.Name, MessageBoxButtons.OK, MessageBoxIcon.Warning); }
        private void OfferRestart(string message)
        {
            using (var dialog = new Form()) {
                Theme.Setup(dialog, "디스크 검사 예약 확인", new Size(485, 225)); dialog.FormBorderStyle = FormBorderStyle.FixedDialog;
                dialog.StartPosition = FormStartPosition.CenterParent; dialog.MaximizeBox = false; dialog.MinimizeBox = false;
                var content = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(20), RowCount = 2, ColumnCount = 1 };
                content.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); content.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));
                content.Controls.Add(Theme.Label(message + "\r\n\r\n재부팅 전에 열려 있는 문서와 작업을 저장하십시오.", 10, false));
                var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft };
                var later = Theme.Button("나중에"); later.DialogResult = DialogResult.Cancel;
                var now = Theme.Button("지금 재부팅"); now.DialogResult = DialogResult.OK; buttons.Controls.Add(later); buttons.Controls.Add(now);
                content.Controls.Add(buttons, 0, 1); dialog.Controls.Add(content); dialog.CancelButton = later; dialog.AcceptButton = later;
                if (dialog.ShowDialog(this) == DialogResult.OK && MessageBox.Show(this, "저장하지 않은 작업이 없는지 확인하십시오. 지금 Windows를 재부팅하시겠습니까?", Metadata.Name,
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) == DialogResult.Yes) {
                    // /t 0 avoids the implicit forced close associated with a positive timeout; /f is intentionally absent.
                    WindowsTools.Open("shutdown.exe", "/r /t 0");
                }
            }
        }
    }
}
