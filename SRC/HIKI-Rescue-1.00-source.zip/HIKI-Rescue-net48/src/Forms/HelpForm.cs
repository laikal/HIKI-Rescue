using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace HikiRescue
{
    internal sealed class HelpForm : Form
    {
        internal static List<Topic> LoadTopics()
        {
            using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("HikiRescue.Help.xml")) {
                if (stream == null) throw new InvalidOperationException("내장 도움말을 읽을 수 없습니다.");
                return XDocument.Load(stream).Root.Elements("topic").Select(x => new Topic { Title = (string)x.Attribute("title"), Body = x.Value }).ToList();
            }
        }
        public HelpForm(int selected)
        {
            Theme.Setup(this, "HIKI Rescue 도움말", new Size(820, 540));
            ShowInTaskbar = false; StartPosition = FormStartPosition.CenterParent;
            var root = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(20), RowCount = 2, ColumnCount = 1 };
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 48)); root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            root.Controls.Add(Theme.Label("도움말   /   버전 " + Metadata.Version, 17, true), 0, 0);
            var split = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1 };
            split.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            split.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 205)); split.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            var list = new ListBox { Dock = DockStyle.Fill, BorderStyle = BorderStyle.FixedSingle,
                IntegralHeight = false, ItemHeight = 36, DrawMode = DrawMode.OwnerDrawFixed, Margin = new Padding(0, 0, 16, 0) };
            list.DrawItem += delegate(object sender, DrawItemEventArgs e) {
                if (e.Index < 0) return;
                e.DrawBackground();
                TextRenderer.DrawText(e.Graphics, list.Items[e.Index].ToString(), list.Font,
                    new Rectangle(e.Bounds.X + 8, e.Bounds.Y, e.Bounds.Width - 10, e.Bounds.Height), e.ForeColor,
                    TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
                e.DrawFocusRectangle();
            };
            var detail = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 2, ColumnCount = 1, Margin = new Padding(0) };
            detail.RowStyles.Add(new RowStyle(SizeType.Absolute, 44)); detail.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            var heading = Theme.Label("", 14, true);
            var text = new RichTextBox { Dock = DockStyle.Fill, ReadOnly = true, BackColor = Color.White,
                BorderStyle = BorderStyle.None, DetectUrls = false, Font = new Font("맑은 고딕", 10.5F), ScrollBars = RichTextBoxScrollBars.Vertical };
            list.SelectedIndexChanged += delegate {
                var topic = list.SelectedItem as Topic;
                if (topic == null) return;
                heading.Text = topic.Title;
                // RTF paragraph spacing is embedded; no browser or external help files are required.
                var rtf = new StringBuilder(@"{\rtf1\ansi\deff0{\fonttbl{\f0 Malgun Gothic;}}\f0\fs21\sl300\slmult1 ");
                foreach (char c in topic.Body.Replace("\r", "")) {
                    if (c == '\n') rtf.Append(@"\par ");
                    else if (c == '\\' || c == '{' || c == '}') rtf.Append('\\').Append(c);
                    else if (c > 127) rtf.Append(@"\u").Append((short)c).Append('?');
                    else rtf.Append(c);
                }
                text.Rtf = rtf.Append('}').ToString(); text.Select(0, 0); text.ScrollToCaret();
            };
            foreach (Topic topic in LoadTopics()) list.Items.Add(topic);
            detail.Controls.Add(heading, 0, 0); detail.Controls.Add(text, 0, 1);
            split.Controls.Add(list, 0, 0); split.Controls.Add(detail, 1, 0); root.Controls.Add(split, 0, 1); Controls.Add(root);
            list.SelectedIndex = Math.Max(0, Math.Min(selected, list.Items.Count - 1));
            KeyPreview = true; KeyDown += delegate(object sender, KeyEventArgs e) { if (e.KeyCode == Keys.Escape) Close(); };
        }
    }
}
