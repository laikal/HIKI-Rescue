using System;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace HikiRescue
{
    internal sealed class AdminPromptForm : Form
    {
        public AdminPromptForm()
        {
            Theme.Setup(this, Metadata.Name, new Size(495, 235));
            FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = false;
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(24), ColumnCount = 1, RowCount = 2 };
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
            layout.Controls.Add(Theme.Label("HIKI Rescue의 시스템 복구 기능을 사용하려면\r\n관리자 권한이 필요합니다.\r\n\r\n관리자 권한으로 다시 실행하시겠습니까?", 10, false), 0, 0);
            var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft, Margin = new Padding(0) };
            var quit = Theme.Button("종료"); quit.DialogResult = DialogResult.Cancel;
            var elevate = Theme.Button("관리자 권한으로 다시 실행"); elevate.Width = 235; elevate.DialogResult = DialogResult.OK;
            buttons.Controls.Add(quit); buttons.Controls.Add(elevate); layout.Controls.Add(buttons, 0, 1);
            Controls.Add(layout); AcceptButton = elevate; CancelButton = quit;
        }
    }
}
