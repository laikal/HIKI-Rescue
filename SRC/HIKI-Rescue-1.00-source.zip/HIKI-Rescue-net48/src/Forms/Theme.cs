using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace HikiRescue
{
    internal static class Theme
    {
        // One embedded multi-size icon, shared for the lifetime of the application.
        private static readonly Icon ApplicationIcon = LoadApplicationIcon();
        private static Icon LoadApplicationIcon()
        {
            using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("HikiRescue.HIKI_Rescue.ico")) {
                if (stream == null) throw new InvalidOperationException("내장 프로그램 아이콘을 읽을 수 없습니다.");
                using (var icon = new Icon(stream)) return (Icon)icon.Clone();
            }
        }
        public static readonly Color Ink = Color.FromArgb(27, 43, 61);
        public static readonly Color Accent = Color.FromArgb(24, 92, 139);
        public static readonly Color Background = Color.FromArgb(245, 247, 250);
        public static void Setup(Form form, string title, Size size)
        {
            form.Text = title; form.ClientSize = size; form.MinimumSize = new Size(size.Width + 16, size.Height + 39);
            form.StartPosition = FormStartPosition.CenterScreen;
            form.Font = new Font("맑은 고딕", 10F); form.ForeColor = Ink; form.BackColor = Background;
            form.AutoScaleMode = AutoScaleMode.Dpi;
            form.Icon = ApplicationIcon;
        }
        public static Button Button(string text)
        {
            return new Button { Text = text, AutoSize = false, Size = new Size(102, 34),
                FlatStyle = FlatStyle.Flat, BackColor = Color.White, ForeColor = Accent, Cursor = Cursors.Hand,
                Margin = new Padding(6, 0, 0, 0), UseVisualStyleBackColor = false };
        }
        public static Label Label(string text, float size, bool bold)
        {
            return new Label { Text = text, AutoSize = false, Dock = DockStyle.Fill,
                Font = new Font("맑은 고딕", size, bold ? FontStyle.Bold : FontStyle.Regular), TextAlign = ContentAlignment.MiddleLeft };
        }
    }
}
