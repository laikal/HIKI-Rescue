using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace HikiRescue
{
    internal sealed class AboutForm : Form
    {
        private readonly Image character;
        internal static Image LoadCharacter()
        {
            using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("HikiRescue.HikiAbout.png")) {
                if (stream == null) throw new InvalidOperationException("내장 About 이미지를 읽을 수 없습니다.");
                using (var original = Image.FromStream(stream)) return new Bitmap(original);
            }
        }
        public AboutForm()
        {
            Theme.Setup(this, "HIKI Rescue 정보", new Size(640, 490));
            FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = false;
            ShowInTaskbar = false; StartPosition = FormStartPosition.CenterParent;
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(24), ColumnCount = 1, RowCount = 4 };
            int[] heights = { 230, 136, 30, 46 };
            foreach (int height in heights) layout.RowStyles.Add(new RowStyle(SizeType.Absolute, height));
            var upper = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, Margin = new Padding(0) };
            upper.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 230)); upper.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            upper.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            character = LoadCharacter();
            var picture = new PictureBox { Image = character, SizeMode = PictureBoxSizeMode.Zoom,
                Dock = DockStyle.Fill, Margin = new Padding(0, 5, 15, 5), BackColor = Color.Transparent, TabStop = false,
                AccessibleName = "히키 캐릭터" };
            var details = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 5, Padding = new Padding(8, 10, 0, 12), Margin = new Padding(0) };
            foreach (int height in new[] { 50, 34, 54, 30, 30 }) details.RowStyles.Add(new RowStyle(SizeType.Absolute, height));
            details.Controls.Add(Theme.Label(Metadata.Name, 24, true), 0, 0);
            details.Controls.Add(Theme.Label("버전 " + Metadata.Version, 12, true), 0, 1);
            var subtitle = Theme.Label("Windows 복구 및 점검 유틸리티", 10, false);
            subtitle.UseMnemonic = false;
            details.Controls.Add(subtitle, 0, 2);
            details.Controls.Add(Theme.Label("개발자: " + Metadata.Creator, 10, false), 0, 3);
            details.Controls.Add(Theme.Label(Metadata.Recipient + " 전용 프로그램", 10, false), 0, 4);
            upper.Controls.Add(picture, 0, 0); upper.Controls.Add(details, 1, 0); layout.Controls.Add(upper, 0, 0);
            layout.Controls.Add(Theme.Label("HIKI Rescue는 Eltax가 Hikimori Neko를 위해 제작한\r\nWindows 복구 및 점검 보조 유틸리티입니다.\r\n\r\nWindows에 기본 포함된 복원, 시스템 점검,\r\n디스크 검사, 디스크 정리 및 디스플레이 복구 기능을\r\n간단하게 사용할 수 있도록 구성했습니다.", 10, false), 0, 1);
            layout.Controls.Add(Theme.Label(Metadata.Copyright, 9, false), 0, 2);
            var close = Theme.Button("확인"); close.Anchor = AnchorStyles.Right; close.DialogResult = DialogResult.OK;
            layout.Controls.Add(close, 0, 3); Controls.Add(layout); AcceptButton = close; CancelButton = close;
        }
        protected override void Dispose(bool disposing) { if (disposing && character != null) character.Dispose(); base.Dispose(disposing); }
    }
}
